class Comix1 < ActiveRecord::Base
end
