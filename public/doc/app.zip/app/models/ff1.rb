class Ff1 < ActiveRecord::Base
end
