class Wcart < ActiveRecord::Base
end
