class Podval < ActiveRecord::Base
end
