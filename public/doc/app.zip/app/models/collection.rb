class Collection < ActiveRecord::Base
  belongs_to :cat1
end
