class Likeit < ActiveRecord::Base
  belongs_to :korder
end
