class Forwarder < ActiveRecord::Base
end
