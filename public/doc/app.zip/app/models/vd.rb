class Vd < ActiveRecord::Base
end
