class Legal < ActiveRecord::Base
end
