class It < ActiveRecord::Base
end
