class Printerrash < ActiveRecord::Base
  belongs_to :printer
  belongs_to :rashod
end
