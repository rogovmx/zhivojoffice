class Manager < ActiveRecord::Base

end