class Cakecart < ActiveRecord::Base
end
