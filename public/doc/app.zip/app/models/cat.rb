class Cat < ActiveRecord::Base
  belongs_to :g3
end
