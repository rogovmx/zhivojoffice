class Coment < ActiveRecord::Base
end
