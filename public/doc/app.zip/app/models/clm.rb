class Clm < ActiveRecord::Base
belongs_to :mamager1
belongs_to :client
end
