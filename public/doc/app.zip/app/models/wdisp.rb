class Wdisp < ActiveRecord::Base
end
