class Mskpaper < ActiveRecord::Base
end
