class Nprice1 < ActiveRecord::Base
end
