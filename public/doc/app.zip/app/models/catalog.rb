class Catalog < ActiveRecord::Base
end
