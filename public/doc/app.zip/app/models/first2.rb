class First2 < ActiveRecord::Base
end
