class Office1 < ActiveRecord::Base
end
