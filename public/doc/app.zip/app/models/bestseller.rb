class Bestseller < ActiveRecord::Base
end
