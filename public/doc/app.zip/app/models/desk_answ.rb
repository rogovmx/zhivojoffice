class DeskAnsw < ActiveRecord::Base
  belongs_to :desk_subj
end
