class Lineitem < ActiveRecord::Base
   belongs_to :order
end
