class Master < ActiveRecord::Base
end
