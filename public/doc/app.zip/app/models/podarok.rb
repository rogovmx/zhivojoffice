class Podarok < ActiveRecord::Base
end
