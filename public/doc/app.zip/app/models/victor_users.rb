class VictorUsers < ActiveRecord::Base
end
