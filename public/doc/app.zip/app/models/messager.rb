class Messager < ActiveRecord::Base
end
