class Raspr1 < ActiveRecord::Base
end
