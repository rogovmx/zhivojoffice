class KeitCart < ActiveRecord::Base
  has_many :set1
end
