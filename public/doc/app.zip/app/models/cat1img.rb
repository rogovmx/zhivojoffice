class Cat1img < ActiveRecord::Base
  belongs_to :cat1
end
