class Water1 < ActiveRecord::Base
end
