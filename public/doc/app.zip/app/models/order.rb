class Order < ActiveRecord::Base
  has_many :lineitem
end
