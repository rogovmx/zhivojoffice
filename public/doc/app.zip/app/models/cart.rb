class Cart < ActiveRecord::Base
end
