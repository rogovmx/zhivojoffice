class Bcat1 < ActiveRecord::Base
  belongs_to :btg1
  belongs_to :cat1
end
