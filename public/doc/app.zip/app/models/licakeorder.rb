class Licakeorder < ActiveRecord::Base
  belongs_to :cakeorder1
end
