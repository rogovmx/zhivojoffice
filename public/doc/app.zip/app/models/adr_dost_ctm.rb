class AdrDostCtm < ActiveRecord::Base
end
