class Btg1 < ActiveRecord::Base
  has_many :btg1har
  has_many :bcat1
end
