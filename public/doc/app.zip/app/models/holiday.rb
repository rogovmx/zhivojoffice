class Holiday < ActiveRecord::Base
end
