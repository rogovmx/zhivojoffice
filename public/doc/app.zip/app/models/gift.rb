class Gift < ActiveRecord::Base
end
