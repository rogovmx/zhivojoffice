class Cake1 < ActiveRecord::Base
end
