class G1 < ActiveRecord::Base
  has_many :g2
end
