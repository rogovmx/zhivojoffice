class G2 < ActiveRecord::Base
  belongs_to :g1
    has_many :g3
end
