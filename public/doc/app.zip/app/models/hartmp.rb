class Hartmp < ActiveRecord::Base
end
