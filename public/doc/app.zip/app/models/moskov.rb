class Moskov < ActiveRecord::Base
end
