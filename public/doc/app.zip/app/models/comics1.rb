class Comics1 < ActiveRecord::Base
  validates_presence_of :contacts
end
