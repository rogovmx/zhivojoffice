class Cat1 < ActiveRecord::Base
  #cattr_reader :per_page
    #@@per_page = 5
 has_many :cat1img
 has_many :collection
 has_one :bcat1
end
