class Tov2 < ActiveRecord::Base
end
