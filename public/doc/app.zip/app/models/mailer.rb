class Mailer < ActionMailer::Base
  

  def welcome(mail,name,name_l,password,surname,phone,rnd)
 # def welcome(mail,rnd)
    subject    'Спасибо за регистрацию!'
    recipients mail
    from      'welcome@zhivojoffice.ru'
    sent_on    Time.now
    body      :rnd=>rnd,:mail=>mail,:name=>name,:password=>password,:name_l=>name_l,:surname=>surname,:phone=>phone
  end

  def pass(mail,name,rnd)
 # def welcome(mail,rnd)
    subject    'Сервис изменения пароля.'
    recipients [mail,'support1@zhivojoffice.ru']
    from      'welcome@zhivojoffice.ru'
    sent_on    Time.now
    body      :rnd=>rnd,:mail=>mail,:name=>name

  end





  def bonus(mail,name,surname,nach,ost,id )
    subject    'Ваш бонусный счет пополнен!'
    recipients mail
    bcc 'bonus_copy@zhivojoffice.ru'
    from      'Бонусная программа Служебный роман <welcome@zhivojoffice.ru>'
    sent_on    (Time.now + 4.hours)
    body :name=>name ,:surname=>surname,:nach=>nach,:ost=>ost,:id=>id
  end


  def new1(mail , name , name_l , password , surname , phone , company_ind ,inn , city ,dop)
    content_type 'text/html'
    #recipients 'vadim@plusnin.ru'
    if city=='Смоленск'
    subject    ' У нас новый клиент! Смоленск '
    recipients ['lastapova@244424.ru'  , 'opospelova@244424.ru' , 'etsarenkov@244424.ru' , 'kpraksina@244424.ru' , 'smolensk@zhivojoffice.ru' , 'plukicheva@spens.ru', 'izamuraeva@spens.ru', 'inoskova@spens.ru', 'mrogov@spens.ru']
    elsif city=='Москва'
    subject    ' У нас новый клиент! Москва '
    recipients ['izenkova@spens.ru', 'mrogov@spens.ru' , 'ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'plukicheva@spens.ru', 'izamuraeva@spens.ru', 'inoskova@spens.ru']
    elsif city=='Нижний Новгород'
    subject    ' У нас новый клиент! Нижний Новгород '
    recipients ['izenkova@spens.ru', 'mrogov@spens.ru' , 'ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru', 'plukicheva@spens.ru', 'izamuraeva@spens.ru', 'inoskova@spens.ru']
    else
    subject    ' У нас новый клиент! Санкт-Петербург '
    recipients ['izenkova@spens.ru', 'mrogov@spens.ru' ,  'ekorchagina@spens.ru', 'plukicheva@spens.ru', 'izamuraeva@spens.ru', 'inoskova@spens.ru']
    end
    #bcc 'iryabova@spens.ru''izamuraeva@spens.ru'
    #cc 'vplusnin@spens.ru''izamuraeva@spens.ru''iryabova@spens.ru'
    from       'Сайт живой офис <welcome@zhivojoffice.ru>'
    sent_on    4.hours.from_now
    body      :mail=>mail,:name=>name,:password=>password,:name_l=>name_l,:surname=>surname,:phone=>phone,:company_ind=>company_ind,:inn=>inn, :city=>city , :dop=>dop
  end
  
  def zakaz(user,cart,street)
     subject    'new order'
      recipients 'vadim@plusnin.ru'
      from      'Сайт Живой офис <welcome@zhivojoffice.ru>'
      sent_on    Time.now
       
       body :user=>user ,:street=>street
       body["cart"]=cart
  end

  def zakaz1(order)
     content_type 'text/html'
     subject    'new order'
     # recipients 'vadim@plusnin.ru'
    user=User.find_by_id(order.user_id)
    @legals=Client.find(order.legal_id)
    manager=Kontragent.find :first , :conditions=>['k1c=?',@legals.k1c] if @legals
    mail=Manager.find(:first , :conditions=>['name=?', manager.manager]) if manager and manager.manager != nil


     if user.city=='Смоленск'
     
       recipients ['opospelova@244424.ru' , 'etsarenkov@244424.ru' , 'lastapova@244424.ru', 'smolensk@zhivojoffice.ru' , 'mrogov@spens.ru', 'zakaz_1csml@spens.ru', 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']
   
     elsif user.city=='Москва'
       if mail and mail.email != nil
       recipients ['ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru', mail.email]
       else
       recipients ['ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']
       end
     elsif user.city=='Нижний Новгород'   
      recipients [ 'ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']
     else
      if mail and mail.email != nil
      recipients ['izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1c@spens.ru', 'plukicheva@spens.ru' , 'ekorchagina@spens.ru' , mail.email]
      else
      recipients ['izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1c@spens.ru', 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru', 'ekorchagina@spens.ru']
      end
     end
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'
     
      sent_on    4.hours.from_now


       body["order"]=order
  end


    def zakaz1user(order, rnd)
     content_type 'text/html'
     subject    'Ваш заказ. Живой офис'
     # recipients 'vadim@plusnin.ru'
    user=User.find_by_id(order.user_id)

      recipients user.mail
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'
      sent_on    Time.now
      body :order=>order ,:rnd=>rnd

  end

     def needs(need)
     content_type 'text/html'
     subject    'Заказ того, чего нет в каталоге'

      recipients 'mrogov@spens.ru'
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'
      sent_on    Time.now
      body :need=>need

  end



def feedback(fb)
     content_type 'text/html'
     subject    'Обратная связь. Сайт Живой офис'

      recipients 'aagranovskii@spens.ru'
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'
      sent_on    Time.now
      body["fb"]=fb

  end



   def zakaz2(order)
     content_type 'text/html'
     subject    'new order'
     # recipients 'vadim@plusnin.ru'
         user=User.find_by_id(order.user_id)
    @legals=Client.find(order.legal_id)
    manager=Kontragent.find :first , :conditions=>['k1c=?',@legals.k1c] if @legals
    mail=Manager.find(:first , :conditions=>['name=?', manager.manager]) if manager and manager.manager != nil


     if user.city=='Смоленск'

       recipients ['opospelova@244424.ru' , 'etsarenkov@244424.ru' , 'lastapova@244424.ru', 'smolensk@zhivojoffice.ru' , 'mrogov@spens.ru', 'zakaz_1csml@spens.ru', 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']

     elsif user.city=='Москва'
       if mail and mail.email != nil
       recipients ['ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru',  mail.email]
       else
       recipients ['ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']
       end
     elsif user.city=='Нижний Новгород'
      recipients ['ekozhevnikova@7303077.ru' , 'eguseva@7303077.ru' , 'izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1cmsk@spens.ru' , 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru']

     else
      if mail and mail.email != nil
      recipients ['izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1c@spens.ru', 'plukicheva@spens.ru', 'ekorchagina@spens.ru' , mail.email]
      else
      recipients ['izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1c@spens.ru', 'plukicheva@spens.ru' , 'izamuraeva@spens.ru', 'inoskova@spens.ru', 'ekorchagina@spens.ru']
      end
     end
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

     sent_on  4.hours.from_now


       body["order"]=order
   end

  def zakaz21 (order)
     content_type 'text/html'
     subject    'new order'
     # recipients 'vadim@plusnin.ru'
     recipients    ['izenkova@spens.ru', 'mrogov@spens.ru','zakaz_1c@spens.ru']
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

      sent_on    Time.now


       body["order"]=order
  end

  def zbonus (order)

     @user=User.find(order[0].user_id)
     @legals=Client.find(@user.client1_id)
    manager=Kontragent.find :first , :conditions=>['k1c=?',@legals.k1c] if @legals
    mail=Manager.find(:first , :conditions=>['name=?', manager.manager]) if manager and manager.manager != nil


     content_type 'text/html'
     subject    'new order bonus'
     if @user.city=='Смоленск'
     recipients    ['izenkova@spens.ru', 'mrogov@spens.ru','opospelova@244424.ru','etsarenkov@244424.ru', 'lastapova@244424.ru']
     else
       if mail and mail.email != nil
       recipients    ['izenkova@spens.ru', 'mrogov@spens.ru' , mail.email]
       else
       recipients    ['izenkova@spens.ru', 'mrogov@spens.ru']
       end
     end
    #recipients    ['vplusnin@spens.ru', 'vplusnin@spens.ru']
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

    sent_on    4.hours.from_now


       body["order"]=order 
      # body :k1c=>k1c ,:name=>name
  end

  def  zz(phone,name,quest,m)
    subject    'Пожалуйста позвоните мне'
    recipients ['mrogov@spens.ru', 'IZenkova@spens.ru']
    from      'Сайт Живой офис сервис заказ звонка  <welcome@zhivojoffice.ru>'
    sent_on    Time.now
    body :phone=>phone , :name=>name,:quest=>quest

  end

  def np(id,k1c,tov3_id)
    content_type 'text/html'
     subject    'Проблемы с ценой'
    recipients ['mrogov@spens.ru','asmirnova@spens.ru','ekorchagina@spens.ru']
    from      'Сайт Живой офис проблемы с ценой  <welcome@zhivojoffice.ru>'
    sent_on    Time.now
    body :k1c=>k1c , :id=>id ,:tov3_id=>tov3_id

  end

  def ep()
    content_type 'text/html'
     subject    'Я робот'
    recipients 'mrogov@spens.ru'
    from      'Сайт Живой офис  рассылка  <welcome@zhivojoffice.ru>'
    sent_on    Time.now
   

  end
  def netf(text)
    content_type 'text/html'
     subject    'Я робот,нет файла '+text
    recipients  'mrogov@spens.ru'
    from      'Сайт Живой офис  рассылка  <welcome@zhivojoffice.ru>'
    sent_on    Time.now


  end

  def tort1(order)
     content_type 'text/html'
     subject    'новый торт'

               recipients    [ 'mrogov@spens.ru' , 'pastry@summerpalace.ru' , 'a.k@summerpalace.ru']
              # recipients    ['mrogov@spens.ru']
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

      sent_on    Time.now


       body["order"]=order
  end

   def water1(order)
     content_type 'text/html'
     subject    'Заказ воды'
               recipients    [ 'mrogov@spens.ru' , 'sale@aquapro-ws.ru' , 'aquapro-ws@mail.ru']
              # recipients    ['vplusnin@spens.ru','epikaleva@spens.ru', 'mrogov@spens.ru' , 'pastry@summerpalace.ru' , 'a.k@summerpalace.ru']
              # recipients    ['mrogov@spens.ru']
      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

      sent_on    Time.now


       body["order"]=order
   end

   def keit1(order)
     content_type 'text/html'
     subject    'Кейтеринг'
               recipients    ['mrogov@spens.ru' , 'mf@anc-group.ru' , 'banket@anc-group.ru' ]

      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

      sent_on    Time.now


       body["order"]=order
   end

   def viktorina(order)
     content_type 'text/html'
     subject    'Победитель викторины'
               recipients    ['mrogov@spens.ru' , 'epikaleva@spens.ru' , 'izamuraeva@spens.ru' ]

      from      'Сайт Живой офис  <welcome@zhivojoffice.ru>'

      sent_on    Time.now


       body["order"]=order
   end

def mailer2(user)

content_type 'text/html'
subject  'баночка вишневого варенья и многое другое'
recipients   user
from  'Сайт Живой офис  <welcome@zhivojoffice.ru>'
sent_on  Time.now
body

end


def mailer(user)

content_type 'multipart/related'
subject  'С всемирным днем кошек!'
recipients   user.mail
from  'welcome@zhivojoffice.ru'
sent_on  Time.now


part :content_type => 'text/html',
:body => '<a href="http://zhivojoffice.ru//"> <img src="cid:part1@domain.com" border="0" > </a>',
:content_disposition => 'inline',
:headers => { 'content-id' => '<html-1@domain.com>' }

part :content_type => 'image/jpeg',
:content_disposition => 'inline',
:transfer_encoding => 'base64',
:body => File.read(RAILS_ROOT+"/public/images/catday.jpg"),
:filename => 'catday.jpg',
:headers => { 'content-id' => '<part1@domain.com>' }
end


end
