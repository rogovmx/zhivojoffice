class Konkursitem < ActiveRecord::Base
  belongs_to :konkursorder
end
