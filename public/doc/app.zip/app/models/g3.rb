class G3 < ActiveRecord::Base
  belongs_to :g2
  has_many :cat
end
