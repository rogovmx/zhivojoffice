class TovSpec < ActiveRecord::Base
end
