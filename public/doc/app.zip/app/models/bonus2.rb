class Bonus2 < ActiveRecord::Base

end
