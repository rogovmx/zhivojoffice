class Set1 < ActiveRecord::Base
  belongs_to :keitering
end
