class Need < ActiveRecord::Base
 # validates_numericality_of :quantity
end
