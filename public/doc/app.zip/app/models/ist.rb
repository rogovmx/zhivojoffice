class Ist < ActiveRecord::Base
end
