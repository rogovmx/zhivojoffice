class LegalCrm < ActiveRecord::Base
end
