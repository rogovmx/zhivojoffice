class Bonus1 < ActiveRecord::Base
end
