class Konkursimg < ActiveRecord::Base
  belongs_to :konkurs1
end
