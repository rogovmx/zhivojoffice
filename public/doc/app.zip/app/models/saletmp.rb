class Saletmp < ActiveRecord::Base
end
