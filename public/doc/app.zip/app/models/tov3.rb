class Tov3 < ActiveRecord::Base
end
