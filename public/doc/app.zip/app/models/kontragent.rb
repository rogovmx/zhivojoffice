class Kontragent < ActiveRecord::Base
end
