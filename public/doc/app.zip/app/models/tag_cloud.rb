class TagCloud < ActiveRecord::Base
end
