class First1 < ActiveRecord::Base
end
