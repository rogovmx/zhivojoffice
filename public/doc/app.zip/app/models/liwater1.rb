class Liwater1 < ActiveRecord::Base
  belongs_to :worder
end
