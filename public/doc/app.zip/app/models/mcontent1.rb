class Mcontent1 < ActiveRecord::Base
end
