class Vote1 < ActiveRecord::Base
end
