class First3 < ActiveRecord::Base
end
