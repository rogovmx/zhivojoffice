class UserCrm < ActiveRecord::Base
end
