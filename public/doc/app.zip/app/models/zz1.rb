class Zz1 < ActiveRecord::Base
end
