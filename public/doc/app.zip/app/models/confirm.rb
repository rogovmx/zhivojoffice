class Confirm < ActiveRecord::Base
end
