class AdrDost < ActiveRecord::Base
end
