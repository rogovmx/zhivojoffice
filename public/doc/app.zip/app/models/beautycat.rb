class Beautycat < ActiveRecord::Base
end
