class Konkurs1 < ActiveRecord::Base
  has_many :konkursimg
end
