class Bonus3 < ActiveRecord::Base

end