class ErUploadUniver < ActiveRecord::Base
end
