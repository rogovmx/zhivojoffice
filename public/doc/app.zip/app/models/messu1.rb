class Messu1 < ActiveRecord::Base
end
