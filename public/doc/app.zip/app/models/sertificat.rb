class Sertificat < ActiveRecord::Base
end
