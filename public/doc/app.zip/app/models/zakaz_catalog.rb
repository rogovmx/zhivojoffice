class ZakazCatalog < ActiveRecord::Base
end
