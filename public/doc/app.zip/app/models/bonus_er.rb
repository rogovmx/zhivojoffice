class BonusEr < ActiveRecord::Base
end
