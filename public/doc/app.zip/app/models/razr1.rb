class Razr1 < ActiveRecord::Base
end
