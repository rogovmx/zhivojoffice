class Newspic < ActiveRecord::Base
end
