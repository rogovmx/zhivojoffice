class Monitoring < ActiveRecord::Base
end
