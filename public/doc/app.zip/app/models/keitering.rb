class Keitering < ActiveRecord::Base
end
