class PredZakaz < ActiveRecord::Base
end
