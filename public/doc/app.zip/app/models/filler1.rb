class Filler1 < ActiveRecord::Base
end
