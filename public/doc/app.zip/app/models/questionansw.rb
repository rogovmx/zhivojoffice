class Questionansw < ActiveRecord::Base
end
