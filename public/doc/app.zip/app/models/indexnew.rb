class Indexnew < ActiveRecord::Base
end
