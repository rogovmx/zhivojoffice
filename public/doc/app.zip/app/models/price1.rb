

class Price1 < ActiveRecord::Base
 
end
