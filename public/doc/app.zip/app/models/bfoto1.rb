class Bfoto1 < ActiveRecord::Base

end