class Received < ActiveRecord::Base
end
