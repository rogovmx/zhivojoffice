class VictUsersQ < ActiveRecord::Base
end
