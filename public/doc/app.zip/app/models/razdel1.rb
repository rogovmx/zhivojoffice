class Razdel1 < ActiveRecord::Base
end
