class Raspr22 < ActiveRecord::Base
end
