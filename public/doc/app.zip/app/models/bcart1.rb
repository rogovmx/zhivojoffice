class Bcart1 < ActiveRecord::Base
end
