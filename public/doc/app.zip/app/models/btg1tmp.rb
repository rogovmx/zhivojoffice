class Btg1tmp < ActiveRecord::Base
end
