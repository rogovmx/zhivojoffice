class Foo1 < ActiveRecord::Base
end
