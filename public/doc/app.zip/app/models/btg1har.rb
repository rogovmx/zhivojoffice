class Btg1har < ActiveRecord::Base
  
  belongs_to :btg1

end
