class Victorina < ActiveRecord::Base
end
