class Statp < ActiveRecord::Base
end
