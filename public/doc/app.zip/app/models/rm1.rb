class Rm1 < ActiveRecord::Base
end
