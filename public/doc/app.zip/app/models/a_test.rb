class ATest < ActiveRecord::Base
end
