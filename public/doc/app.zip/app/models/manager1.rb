class Manager1 < ActiveRecord::Base
has_many :clm
has_many :client ,:through =>:clm
end