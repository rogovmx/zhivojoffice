class MUsers < ActiveRecord::Base
end
