class Konkursorder < ActiveRecord::Base
  has_many :konkursitem
end
