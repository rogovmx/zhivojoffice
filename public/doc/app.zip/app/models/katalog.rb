class Katalog < ActiveRecord::Base
end
