class Sale < ActiveRecord::Base
end
