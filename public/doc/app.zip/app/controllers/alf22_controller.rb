class Alf22Controller < ApplicationController
  def index
    @tov3=Tov3.find :all
    @tov3.each do |t3|
      ss=t3.name
      t3.reserv=ss
      t3.save
    end
    @rr='ok'
  end

end
