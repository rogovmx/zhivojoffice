   require 'net/http'
  # require 'rexml/document'
   require 'iconv'

class Kt1Controller < ApplicationController
  #layout 'spens1'
 #layout 'kanct'
   layout 'l_o1'
   layout 'index' , :only=>'index'
   
   require "will_paginate"
   skip_before_filter :verify_authenticity_token, :only => [:chng_pic]

  def locateip

  ip = request.env["HTTP_X_FORWARDED_FOR"] || request.remote_addr;
 #ip = request.remote_ip
 ips = ip.to_s
 url = "http://ipgeobase.ru:7020/geo?ip="+ips
 #url = "http://www.litecode.ru/services/geobase.shtml?ip="+ips  
 xml_data = Net::HTTP.get_response(URI.parse(url)).body
 converter=Iconv.new('UTF-8','Windows-1251')
 city=converter.iconv(xml_data)
 city=xml_data
 
 if city['Москва']!=nil
  iplocation='msk'
 elsif city['Смоленск']!=nil
   iplocation='smo'
 elsif city['Нижний Новгород']!=nil
   iplocation='nn'
 else 
   iplocation='spb'
 end


 return iplocation
end

  def go2see
    redirect_to 'http://go2see.ru/promo'
  end

   
   def franchise
    render :layout=>'l_o1_pr'
   end
  
#  def initialize
#    @bestseller=Bestseller.find :all
#    @sp=Ist.find:all
#   end

  def user
    @user=User.find_by_id(session[:user_id])
  end


  def index
    session[:original_uri]=request.request_uri
     user
     cart
   #  unless read_fragment(:fragment=>'kt1index1')

if session[:city]== nil
    ip=locateip()
     
     if ip=='smo'
     session[:city]='smo'
     elsif ip=='msk'
     session[:city]='msk'
     elsif ip=='nn'
     session[:city]='nn'
     else
     session[:city]='spb' #unless session[:city]
     end

    end
     @uri=session[:original_uri]
    # @uri=request.request_uri
    if params[:id]
        id=params[:id].to_i
        @k=First1.find:all,:select=>"name ,kod, id",:conditions=>["kod >? and kod <?",id*100, (id+1)*100] ,:order=>'kod'
        if id==10
        @tmp=First1.find :first ,:select=>"name ,kod, id" , :conditions=>['kod=?',907]
        @k<<@tmp
        elsif id==11
        @tmp=First1.find :first ,:select=>"name ,kod, id" , :conditions=>['kod=?',905]
        @k<<@tmp
        end
      @name=Razdel1.find(id).name
    
    end
  end


#  def paper
#     user
#     @k1=First1.find:all,:conditions=>"kod >100 and kod <200"
#  end
#  def tdo
#     user
#     @k2=First1.find:all,:conditions=>"kod >200 and kod <300"
#  end
#
#  def tdov
#     user
#     @k3=First1.find:all,:conditions=>"kod >300"
#  end

#  def kanc
#    cart
#    @gr2=G2.find(:all,:conditions=> ["kzs=?",params[:id]])
#
#     @k=First1.find(:first,:conditions=> ["kod=?",params[:id]])
#  end

  

  def tov
    redirect_to :controller=>'kt3',:action=>'tov',:id=>params[:id]
  end



def create_it
  @it=It.new(params[:it])
  @it.save
  #redirect_to :back
  render(:partial=> '/kt1/it')
end


  def cart
     user
     if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
       @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
       @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
@cart_sum=0
     @cart.each do |cart|
       if cart.quantity == nil
         cart.quantity = 1
         cart.save
       end
       @cart_sum+=cart.price*cart.quantity
     end
     end



 def log1
      render(:partial =>'/part2/login1')
 end

 def edit_tov
       @cat1=Cat1.find(params[:id])
      render(:partial =>'/part/edit_tov',:object=>@cat1)
end

def edit_tov_pics
       @cat1=Cat1.find(params[:id])
      render(:partial =>'/part/edit_tov_pics',:object=>@cat1)
end



def add_tov
       @cat1=Cat1.new
       @id = params[:id]
      render(:partial =>'/part/add_tov',:object=>@cat1, :id => @id )
 end

def save_new
     @cat1.save
   redirect_to :back
end

def edit_tov_pod
       @cat1=Cat1.find(params[:id])
      render(:partial =>'/part/edit_tov_pod',:object=>@cat1)
end

def kt1_spec
      @cat=Cat1.find(params[:id])
      render(:partial =>'kt1_spec',:object=>@cat)
end

 def kt1_st
      @cat=Cat1.find(params[:id])
      render(:partial =>'kt1_st',:object=>@cat)
end

 def kt1_ot
      @cat=Cat1.find(params[:id])
      render(:partial =>'tov_pod1',:object=>@cat)
 end

 def del_tov
    Cat1.destroy(params[:id])
end

  def close
  render :text=>''
  end

  def set_city
   session[:city]= params[:city]
   redirect_to :back
  end

  def rootina
    render :layout=>'search'
  end

def menu
    user
   render :update do |page|
    page.replace_html( 'm_menu', :partial=>'/part2/m_menu' )
    page.visual_effect(:blind_down, 'm_menu', :duration=> 0.2)
    end
end

 def info
    user
   render :update do |page|
    page.replace_html( 'info', :partial=>'/part2/info' )
    page.visual_effect(:blind_down, 'info', :duration=> 0.2)
 end

  end

 def chng_pic
     case params[:id]
     when '0'
     @pic='baner.jpg'
     when '1'
     @pic='baner_00_ruchka.jpg'
     when '2'
     @pic='baner_01_kaktus.jpg'
     when '3'
     @pic='baner_02_roza.jpg'
     when '4'
     @pic='baner_21_nozhnizi.jpg'
     when '5'
     @pic='baner_04_dirikol.jpg'
     when '6'
     @pic='baner_06_tetradi.jpg'
     when '7'
     @pic='baner_11_kreslo.jpg'
     when '8'
     @pic='baner_12_textovivoditel.jpg'
     when '9'
     @pic='baner_20_chainik.jpg'
     when '10'
     @pic='baner_13_orhideya.jpg'
     when '11'
     @pic='baner_19_postit.jpg'
     when '12'
     @pic='baner_18_stepler.jpg'
     when '13'
     @pic='baner_16_lastic.jpg'
     when '14'
     @pic='baner_17_ramka.jpg'
     when '15'
     @pic='baner_15_papka.jpg'
     when '16'
     @pic='baner_10_magnit.jpg'
     when '17'
     @pic='baner_07_kruzhka.jpg'
     when '18'
     @pic='baner_05_lampa.jpg'
     when '19'
     @pic='baner_09_marker.jpg'
     when '20'
     @pic='baner_08_kruasan.jpg'
     when '21'
     @pic='baner_14_karandash.jpg'
     end

 render :partial=>'/part2/chng_pic' , :pic=>@pic
end

def method_missing
 redirect_to '/'
end

end
