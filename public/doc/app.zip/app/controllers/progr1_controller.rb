class Progr1Controller < ApplicationController
  layout 'search'
  def index
    @aa=55
  end

  def letter
    @aa=66
  end

end
