class Vote1sController < ApplicationController
  # GET /vote1s
  # GET /vote1s.xml
  def index
    @vote1s = Vote1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @vote1s }
    end
  end

  # GET /vote1s/1
  # GET /vote1s/1.xml
  def show
    @vote1 = Vote1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @vote1 }
    end
  end

  # GET /vote1s/new
  # GET /vote1s/new.xml
  def new
    @vote1 = Vote1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @vote1 }
    end
  end

  # GET /vote1s/1/edit
  def edit
    @vote1 = Vote1.find(params[:id])
  end

  # POST /vote1s
  # POST /vote1s.xml
  def create
    @vote1 = Vote1.new(params[:vote1])

    respond_to do |format|
      if @vote1.save
        flash[:notice] = 'Vote1 was successfully created.'
        format.html { redirect_to(@vote1) }
        format.xml  { render :xml => @vote1, :status => :created, :location => @vote1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @vote1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /vote1s/1
  # PUT /vote1s/1.xml
  def update
    @vote1 = Vote1.find(params[:id])

    respond_to do |format|
      if @vote1.update_attributes(params[:vote1])
        flash[:notice] = 'Vote1 was successfully updated.'
        format.html { redirect_to(@vote1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @vote1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /vote1s/1
  # DELETE /vote1s/1.xml
  def destroy
    @vote1 = Vote1.find(params[:id])
    @vote1.destroy

    respond_to do |format|
      format.html { redirect_to(vote1s_url) }
      format.xml  { head :ok }
    end
  end
end
