class DelTovController < ApplicationController
  require 'fileutils'
  require "parseexcel"

  layout 'search'
   before_filter :authorize
   before_filter :redaktor
  def index
     file=params[:file]

    exel=Spreadsheet::ParseExcel.parse('public/data/'+file)
    #exel=Spreadsheet::ParseExcel.parse('public/ex1/opis22.xls')
    worksheet = exel.worksheet(0,0)

    worksheet.each { |row|


     i=0
     row.each { |cell|
     #i+=1

     if i==0
       cat_del=cell.to_s('UTF-8')
       cat=Cat1.find :first,:conditions=>["k1c=?",cat_del]
       if cat
       cat.vis=0
       cat.save!
       end
     else
       return
     end
  }

}
 File.delete('public/data/'+file)
 redirect_to :controller=>'kt1'
  end

end
