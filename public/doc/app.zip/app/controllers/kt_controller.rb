class KtController < ApplicationController
  before_filter :authorize
   before_filter :admin_s
  def index
     gr3=params[:id]
    unless gr3
      gr3=35
    end
    gr3=params[:id]
    @gr1=G1.find(:all)
    @gr33=Cat.find(:all,:conditions=> ["g3_id=?",params[:id]])
    @gr75=Cat.find(:first,:conditions=>"g3_id='35'")
  end
  def tov
    pp=params[:id]
    @cat=Cat.find(pp)
    render(:partial =>'cat',:object=>@cat)
  end
  def tov1
    pp=params[:id]
    @cat=Cat.find(pp)
    render(:partial =>'cat1',:object=>@cat)
  end
  def tg
    
    @tg=Cat.find(:all ,:coditions=>["g3_id=?",params[:id]])
  end
  #=========================================================================
   def delcat
     @g33=G3.find(params[:id])
     @g33.cat.destroy_all
     redirect_to :controller=>'kt',:action=>'delgr'
   end
   def delg3
     @g22=G2.find(params[:id])
     @g22.g3.destroy_all
     redirect_to :controller=>'kt',:action=>'delgr'
   end
   def delg2
      @g11=G1.find(params[:id])
     @g11.g2.destroy_all
     redirect_to :controller=>'kt',:action=>'delgr'
   end
   def delgr
      @gr1=G1.find(:all)
     
   end

end
