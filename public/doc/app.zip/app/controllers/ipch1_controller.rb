class Ipch1Controller < ApplicationController
   layout 'l_o1'
  def index
  end

end
