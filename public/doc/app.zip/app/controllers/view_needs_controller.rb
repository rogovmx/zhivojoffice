class ViewNeedsController < ApplicationController
  layout 'vvk_fw'
  def index
    @user=User.find_by_id(session[:user_id])
    @needs = Need.find(:all)
  end

end
