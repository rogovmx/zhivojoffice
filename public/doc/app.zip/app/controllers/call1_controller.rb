class Call1Controller < ApplicationController
  layout 'search_nofoot'
   before_filter :authorize
   before_filter :admin_call
   require 'will_paginate'
 def user
     @user=User.find_by_id(session[:user_id])
 end

  def index
    user
    if @user.city == 'Смоленск'
    @new_user=User.paginate :all,:conditions=>["client1_id=? and old=? and role = ? and city = ?",0,0,'user','Смоленск'] ,:order=>'created_at desc' , :page=>params[:page] , :per_page=>30
    else
    if session[:city]=='msk' or session[:city]=='nn'
    @new_user=User.paginate :all,:conditions=>["client1_id=? and old=? and role = ? and city=?",0,0,'user','Москва'],:order=>'created_at desc' , :page=>params[:page] , :per_page=>30
    else
    @new_user=User.paginate :all,:conditions=>["client1_id=? and old=? and role = ? and city !=? and city !=? and city !=?",0,0,'user','Москва','Нижний Новгород','Смоленск'],:order=>'created_at desc' , :page=>params[:page] , :per_page=>30
    end
    end
  end

  def edit_user
     @user = User.find(params[:id])
  end

 def upd_user
  @user=User.find_by_id(params[:id])
  if @user.update_attributes(params[:user11])
  else
  end
    redirect_to :action=>'index'
 end

  def oldspens
    
  end
  def client_details
    @client=User.find(params[:id])
  end

  def new_client

    @new_user=User.find(params[:id])
    @client=Client.find(params[:client])
    @new_user.client1_id=@client.id
    @new_user.client_id=@client.id
    @new_user.save!
    #render :text=>@new_user.client_id.to_s
    redirect_to :action=>'index'

    #@vid=Vd.find(:all).map{|u| [u.Name,u.id]}

  end

  def del_user
    user=User.find(params[:id])
    user.destroy

    redirect_to :action=>'index'
  end
   def ncc
     @user=User.find(params[:id])
   end

  def  new_client_cart
        @client = Client.new(params[:client])
        @client.save
        @user=User.find(params[:user])
        @user.client_id=@client.id
        @user.client1_id=@client.id
        @user.save
        redirect_to :action=>'index'
  end


  def first1
   # user
    @client=Client.new(params[:client])
    @client.save!
    @new_user=User.find(params[:id_nu])
    @new_user.client_id = @client.id
    @new_user.save!
  @cl= @client.id

  end
  def first2
     @legal=Legal.new(params[:legal])

    @legal.save
  end
   def pr_client

   end


end
