class Foo1sController < ApplicationController
  # GET /foo1s
  # GET /foo1s.xml

  layout 'search'
   before_filter :authorize
   before_filter :redaktor
  def index
    @foo1s = Foo1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @foo1s }
    end
  end

  # GET /foo1s/1
  # GET /foo1s/1.xml
  def show
    @foo1 = Foo1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @foo1 }
    end
  end

  # GET /foo1s/new
  # GET /foo1s/new.xml
  def new
    @foo1 = Foo1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @foo1 }
    end
  end

  # GET /foo1s/1/edit
  def edit
    @foo1 = Foo1.find(params[:id])
  end

  # POST /foo1s
  # POST /foo1s.xml
  def create
    @foo1 = Foo1.new(params[:foo1])

    respond_to do |format|
      if @foo1.save
        flash[:notice] = 'Foo1 was successfully created.'
        format.html { redirect_to(@foo1) }
        format.xml  { render :xml => @foo1, :status => :created, :location => @foo1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @foo1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /foo1s/1
  # PUT /foo1s/1.xml
  def update
    @foo1 = Foo1.find(params[:id])

    respond_to do |format|
      if @foo1.update_attributes(params[:foo1])
        flash[:notice] = 'Foo1 was successfully updated.'
        format.html { redirect_to(@foo1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @foo1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /foo1s/1
  # DELETE /foo1s/1.xml
  def destroy
    @foo1 = Foo1.find(params[:id])
    @foo1.destroy

    respond_to do |format|
      format.html { redirect_to(foo1s_url) }
      format.xml  { head :ok }
    end
  end
end
