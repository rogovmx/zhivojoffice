class First2sController < ApplicationController
  # GET /first2s
  # GET /first2s.xml
  def index
    @first2s = First2.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @first2s }
    end
  end

  # GET /first2s/1
  # GET /first2s/1.xml
  def show
    @first2 = First2.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @first2 }
    end
  end

  # GET /first2s/new
  # GET /first2s/new.xml
  def new
    @first2 = First2.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @first2 }
    end
  end

  # GET /first2s/1/edit
  def edit
    @first2 = First2.find(params[:id])
  end

  # POST /first2s
  # POST /first2s.xml
  def create
    @first2 = First2.new(params[:first2])

    respond_to do |format|
      if @first2.save
        flash[:notice] = 'First2 was successfully created.'
        format.html { redirect_to(@first2) }
        format.xml  { render :xml => @first2, :status => :created, :location => @first2 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @first2.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /first2s/1
  # PUT /first2s/1.xml
  def update
    @first2 = First2.find(params[:id])

    respond_to do |format|
      if @first2.update_attributes(params[:first2])
        flash[:notice] = 'First2 was successfully updated.'
        format.html { redirect_to(@first2) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @first2.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /first2s/1
  # DELETE /first2s/1.xml
  def destroy
    @first2 = First2.find(params[:id])
    @first2.destroy

    respond_to do |format|
      format.html { redirect_to(first2s_url) }
      format.xml  { head :ok }
    end
  end
end
