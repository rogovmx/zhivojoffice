class Fool12Controller < ApplicationController
  def index


  if params[:id] == '1'
       render :partial=>'/part/podval1'

     elsif params[:id] == '2'
       render :partial=>'/part/podval2'
     elsif params[:id] == '3'
         render :partial=>'/part/podval3'
         elsif params[:id] == '4'
         render :partial=>'/part/podval4'
     elsif params[:id] == '5'
         render :partial=>'/part/podval5'
     elsif params[:id] == '6'
         render :partial=>'/part/podval6'
    
     end


  end
end
