class RecoveryController < ApplicationController
    layout 'vvk_fw'
  
  def index
  @f_user= User.new
    
  end

  def find_user
   @f_user = User.new(params[:f_user])
   @ff_user = User.find :first, :conditions=> ['name=?',@f_user.name]

   
  end

end
