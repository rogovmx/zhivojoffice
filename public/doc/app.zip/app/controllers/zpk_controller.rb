class ZpkController < ApplicationController
 layout 'l_o1'
  def index
     @pz =PredZakaz.find :all,:conditions=>["Sesion_id=?",session.session_id]
  end

   def user
    @user=User.find_by_id(session[:user_id])

 end

  def pp
     s=session.session_id
     
    i=0
   while i<11
     pz=PredZakaz.new
     #pz.sesion=session
     pz.Sesion_id= s.to_s
     pz.quantity=1
     pz.save
     i+=1

   end
   redirect_to  :controller=>'zpk',:action=>'index'

  end
  def u1
    user
    PredZakaz.update(params[:pred_zakaz].keys ,params[:pred_zakaz].values)

    @pz=PredZakaz.find :all,:conditions=>["Sesion_id=?",session.session_id]
    @pz.each do |pz|
        if pz.quantity > 0
      if pz.kpk !=''
      cat=Cat1.find :first,:conditions=>["kpk=?",pz.kpk]
      if cat !=nil
      cart=Cart.new
      cart.Sesion_id=session.session_id
      cart.k1s=cat.k1c
      if @user
        @pr_spec=TovSpec.find :first,:conditions=>["k1c=? and legal_id=?",cat.k1c,@user.client_id]
        if @pr_spec !=nil
          cart.price= @pr_spec.price_spec
        else
          cart.price=cat.price
        end
      else
      cart.price=cat.price
      end
      cart.quantity=pz.quantity
      cart.otdel='kanc'
      cart.save
      end
      else
      end
      end
    end
   PredZakaz.delete_all(['Sesion_id=?',session.session_id])


    

    redirect_to  :controller=>'bas1',:action=>'edit_cart'
  end

end
