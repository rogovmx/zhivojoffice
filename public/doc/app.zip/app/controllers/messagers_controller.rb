class MessagersController < ApplicationController
  # GET /messagers
  # GET /messagers.xml
  def index
    @messagers = Messager.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @messagers }
    end
  end

  # GET /messagers/1
  # GET /messagers/1.xml
  def show
    @messager = Messager.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @messager }
    end
  end

  # GET /messagers/new
  # GET /messagers/new.xml
  def new
    @messager = Messager.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @messager }
    end
  end

  # GET /messagers/1/edit
  def edit
    @messager = Messager.find(params[:id])
  end

  # POST /messagers
  # POST /messagers.xml
  def create
    @messager = Messager.new(params[:messager])

    respond_to do |format|
      if @messager.save
        flash[:notice] = 'Messager was successfully created.'
        format.html { redirect_to(@messager) }
        format.xml  { render :xml => @messager, :status => :created, :location => @messager }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @messager.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /messagers/1
  # PUT /messagers/1.xml
  def update
    @messager = Messager.find(params[:id])

    respond_to do |format|
      if @messager.update_attributes(params[:messager])
        flash[:notice] = 'Messager was successfully updated.'
        format.html { redirect_to(@messager) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @messager.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /messagers/1
  # DELETE /messagers/1.xml
  def destroy
    @messager = Messager.find(params[:id])
    @messager.destroy

    respond_to do |format|
      format.html { redirect_to(messagers_url) }
      format.xml  { head :ok }
    end
  end
end
