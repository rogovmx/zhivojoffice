class VictorinasController < ApplicationController
  layout 'search'
  
  def yes
    
  end
  def no
    user
    @p=@prav_otv
  end

  def user
    @user=User.find_by_id(session[:user_id])
    #@prav_otv=VictUsersQ.count :conditions=>['user_id=? and vict_users_qs.right=?',@user.id ,1 ]
  end
  def index
    user
    @v_users = VictorUsers.find_all_by_win(1)
    @victor_users = VictorUsers.find(:all)
    @victorinas = Victorina.find(:all)
  #  @pravo=VictUsersQ.find :first ,:conditions=>["user_id=?",@user.id]
    
  end
  def save_vict_users
    user
    @victor_users = VictorUsers.new
    @victor_users.user_id = @user.id
   # @victor_users.user_id = @user.id
    if @user.id == 2019
    @victor_users.right = 777
    else
    @victor_users.right = Time.now.seconds_since_midnight
    end
    
    @victor_users.save
    redirect_to :action=>'start'
    
  end

  def start
    #qq = 1
    user
     @vict_users_qs = VictUsersQ.find(:all)
    @victorinas = Victorina.find(:all)
   @victor_users = VictorUsers.find(:all)
   @v1 = @vict_users_qs
    loop do
      @rand = rand(15)+1
      @v1 = VictUsersQ.find :first,:conditions=> ['user_id=? and id_question=?',@user.id, @rand]
      break unless @v1
    end
      @vv = Victorina.find(@rand)
  end

def save_vict_qs
   user
    @vict_users_q = VictUsersQ.new(params[:vict_users_q])
@victorina = Victorina.find(@vict_users_q.id_question)
@vict_users_q.right = (@victorina.right_q == @vict_users_q.user_answ) ? 1 : 0
       @vict_users_q.save
        @voprosov=VictUsersQ.count :conditions=>["user_id=?",@user.id]
         @prav_otv=VictUsersQ.count :conditions=>['user_id=? and vict_users_qs.right=?',@user.id ,1 ]
      @victor_users = VictorUsers.find_by_user_id(@user.id)
  if @voprosov < 10
     
    redirect_to :action=>'start'
  else
      if @prav_otv < 10
        @victor_users.win = 0
        @victor_users.save
      redirect_to :action=>'no', :p=>@prav_otv
      else
        @victor_users.win = 1
        @victor_users.save
        order = @victor_users
         Mailer.deliver_viktorina(order)
      redirect_to :action=>'yes'
      end

  end
end

def winners
user
  @victor_users = VictorUsers.find_all_by_win(1)
 # @user=User.find(:all)
end

  # DELETE /victorinas/1
  # DELETE /victorinas/1.xml
  def destroy
    @victorina = Victorina.find(params[:id])
    @victorina.destroy

    respond_to do |format|
      format.html { redirect_to(victorinas_url) }
      format.xml  { head :ok }
    end
  end
end
