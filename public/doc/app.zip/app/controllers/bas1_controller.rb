class Bas1Controller < ApplicationController
  layout 'bas1'
  
 def initialize
  
    @sp=Ist.find:all


  end
   def user
    @user=User.find_by_id(session[:user_id])
   end

   def cart

     if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
       @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum_bonus=0
     @cart_bonus=Cart.find :all,:conditions=>[' sesion_id=? and otdel != ?',session.session_id,'raspr']

     @cart_bonus.each do |cart1|
       if cart1.quantity == '' or cart1.quantity == nil
        cart1.quantity = 1
        cart1.save
       end
       
       @cart_sum_bonus+=cart1.price*cart1.quantity if cart1.price
     end

     @cart_sum=0
     @cart.each do |cart|
        if cart.quantity == '' or cart.quantity == nil
        cart.quantity = 1  
       cart.save
        end
       @cart_sum+=cart.price*cart.quantity if cart.price
     end
     end


  def edit_cart
    user
    cart

    @cart.each do |cart|

 @cat=Cat1.find_by_k1c(cart.k1s)
 cart.destroy unless @cat
    end


    
    if @cart_count == 0
      redirect_to :action=>'no_ver'
    end
      
    
    unless @user

    else
    if @user.client1_id != 0
    @client=Client.find(@user.client1_id)
    
    @legal_count=Legal.count :conditions=>['client_id=?',@client.id]
    @adr_count=AdrDost.count :conditions=>['client_id=?',@client.id]
    @legal=Legal.find(:all,:conditions=>['client_id=?',@client.id]).map{|u| [u.name,u.id]}
    @adr=AdrDost.find(:all,:conditions=>['client_id=?',@client.id]).map{|u| [u.street_id,u.id]}
    else
     @client=Client.find('1')
    end
    end
   
  end

  def konkurs
    @user=User.find_by_id(session[:user_id])

    @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
    @cat1=[]
    @cart.each { |cart| @cat1 << cart.k1s }
    render :layout=>'vvk_fw'

  end

    def konkurs2
    session[:konkurs_id]=params[:id]

    @user=User.find_by_id(session[:user_id])

    @line=Konkursitem.find :all , :conditions=>['konkursorder_id=?' , params[:id]]
    @cat1=[]
    @line.each {|cart| @cat1 << cart.k1s }



  end



  def konkurs_save
    user

   cart

    if @user.client1_id==0
      @client=Client.find(1)
    else
   @client=Client.find(@user.client1_id)
    end

    order=Konkursorder.new(:user_id=>@user.id , :client_id=>@client.id)


     for cart in @cart do
             order.konkursitem << Konkursitem.new(:k1s =>cart.k1s ,:price=>cart.price ,:quantity =>cart.quantity ,:otdel=>cart.otdel,:user1_id=>@user.id)
          end
        order.save

     if @user.client1_id==0
      @client=Client.find(1)
    else
   @client=Client.find(@user.client1_id)
    end

#
#   #Mailer.deliver_zakaz(@user.name,@cart,@street)
#   if order.id
#    Mailer.deliver_zakaz1(order)
#    end
#   Cart.delete_all(['User_id=?',@user.id])
#   Cart.delete_all(['sesion_id=?',session.session_id])
    flash[:notice] = 'Задания на конкурс сохранены'
    redirect_to :back

  end



  def del_cart
     user
     if @user
       Cart.delete_all(['User_id=?',@user.id])
       Cart.delete_all(['sesion_id=?',session.session_id])
     else
        Cart.delete_all(['sesion_id=?',session.session_id])
     end
    redirect_to :action=>'edit_cart'
  end


  def edit_cart_item
    user
    if @user
    cart_item=Cart.find :first,:conditions=>['k1s=? and User_id=?',params[:k1s],@user.id]
    cart_item.quantity=params[:quantity]
    cart_item.save
    else
      cart_item=Cart.find :first,:conditions=>['k1s=? and sesion_id=?',params[:k1s],session.session_id]
      cart_item.quantity=params[:quantity]
      cart_item.save
    end
    redirect_to :action => "edit_cart"
    
  end

  def u1
    user
    Cart.update(params[:cart].keys ,params[:cart].values)

for a in params[:cart].keys do
  tmp=Cart.find(a)
  if tmp.quantity == nil or tmp.quantity == 0
      tmp.quantity=1 
      tmp.save
  end   
end     
 
 #render :text=>params[:cart].values
 #  
redirect_to :back
  end


    def u1_poduser
    user
 Cart.update(params[:cart].keys ,params[:cart].values)
 for a in params[:cart].keys do
  tmp=Cart.find(a)
  if tmp.quantity == nil or tmp.quantity == 0
      tmp.quantity=1
      tmp.save
  end
 end
   @sotr=User.find(params[:us])
   @cart=Cart.find :all,:conditions=>['User1_id=? ',@sotr.id]
   render :partial=>'/cabinet/poduser',:cart=>@cart ,:user=>@user ,:sotr=>@sotr
  end


 def edit_cart_item1
   
 end
 def del_cart_item1
    Cart.update(params[:cart].keys ,params[:cart].values)
   #Cart.destroy(params[:cart].keys,params[:cart].values)
  end



   def del_cart_item
    user

    if @user
    #cart_item=Cart.find :first,:conditions=>['k1s=?',params[:k1s]]
     #cart_item=Cart.find :first,:conditions=>['sesion_id=? and k1s=?',session.session_id,params[:k1s]]
     cart_item=Cart.find :first,:conditions=>['User_id=? and k1s=?',@user.id,params[:k1s]]
    cart_item.destroy
    else
      cart_item=Cart.find :first,:conditions=>['sesion_id=? and k1s=?',session.session_id,params[:k1s]]
    cart_item.destroy
    end
    #redirect_to :action=>'edit_cart'
    redirect_to :back
  end

   def del_cart_item_poduser
    user

     cart_item=Cart.find :first,:conditions=>['user1_id=? and k1s=?',params[:us],params[:k1s]]
    cart_item.destroy
       @sotr=User.find(params[:us])
   @cart=Cart.find :all,:conditions=>['User1_id=? ',@sotr.id]
   render :partial=>'/cabinet/poduser',:cart=>@cart ,:user=>@user ,:sotr=>@sotr
  end

   def priem_poduser
     user
      cart_item=Cart.find :first,:conditions=>['user1_id=? and k1s=?',params[:us],params[:k1s]]
      cart_item.User_id=@user.id
       cart_item.save
       @sotr=User.find(params[:us])
   @cart=Cart.find :all,:conditions=>['User1_id=? ',@sotr.id]
   render :partial=>'/cabinet/poduser',:cart=>@cart ,:user=>@user ,:sotr=>@sotr
     
   end


 def oz
  user
  cart
  if @user
    @client=Client.find(@user.client1_id)
   # @legal_count=Legal.count :conditions=>['client_id=?',@client.id]
   # @adr_count=AdrDost.count :conditions=>['client_id=?',@client.id]
   # @legal=Legal.find(:all,:conditions=>['client_id=?',@client.id]).map{|u| [u.name,u.id]}
   # @adr=AdrDost.find(:all,:conditions=>['client_id=?',@client.id]).map{|u| [u.street_id,u.id]}
   redirect_to :action=>'oz1'
    else
      redirect_to :controller=>'login',:action=>'login'
    end
end


def oz1
   user
   cart
     rnd=rand(999999999999999999999999999999999999999999)
      conf=Confirm.new
      conf.user_id=@user.id
      conf.rnd=rnd
      conf.save
    if @user.client1_id==0
      @client=Client.find(1)
    else
   @client=Client.find(@user.client1_id)
    end
 
   order=Order.new(params[:order])
  
   flag=0
   summa=0
     for cart in @cart do
       flag+=cart.quantity
       order.lineitem << Lineitem.new(:k1c =>cart.k1s ,:price=>cart.price ,:quantity =>cart.quantity ,:otdel=>cart.otdel,:user1_id=>cart.user1_id)
       summa+=(cart.price*cart.quantity)
    end
    if flag >0
    order.summa=summa

    order.save
    else
      redirect_to :action=>'no_ver'
    end

   if order.id
    Mailer.deliver_zakaz1(order)
    Mailer.deliver_zakaz1user(order, rnd) if @user.mail
   Cart.delete_all(['User_id=?',@user.id])
   Cart.delete_all(['sesion_id=?',session.session_id])
    end


end

def oz_poduser
   user
    @cart=Cart.find :all,:conditions=>['user1_id=?',params[:us]]
    sum=@cart.sum{|s| s.price*s.quantity}
    if @user.client1_id==0
      @client=Client.find(1)
    else
   @client=Client.find(@user.client1_id)
    end
  
   order=Order.new(params[:order])
   
   flag=0
     for cart in @cart do
       flag+=cart.quantity
       order.lineitem << Lineitem.new(:k1c =>cart.k1s ,:price=>cart.price ,:quantity =>cart.quantity ,:otdel=>cart.otdel,:user1_id=>cart.user1_id)
    end
    if flag >0
    order.summa=sum
    order.save
   Mailer.deliver_zakaz2(order)
   Cart.delete_all(['user1_id=?',params[:us]])
    else
      flash[:notice] = 'Неправильное количество товара'
    end  

   redirect_to :controller=>'cabinet',:action=>'sotr'

end

def no_ver
 #render :layout=>'vvk'
end

end
