class ActController < ApplicationController
  layout 'search'
  def index
     
     if session[:city]=='smo'
     @content=Statp.find :first, :conditions=>["title=?",'Акции Смоленск']
     else
     @content=Statp.find :first, :conditions=>["title=?",'Акции']  
     end
  end

  def mans
    @content=Statp.find :first, :conditions=>["title=?",'10man']
  end

    def guest
    @content=Statp.find :first, :conditions=>["title=?",'guest']
  end
   def clean
    @content=Statp.find :first, :conditions=>["title=?",'clean']
  end

    def newman
    @content=Statp.find :first, :conditions=>["title=?",'newman']
  end
end
