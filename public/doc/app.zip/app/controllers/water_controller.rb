class WaterController < ApplicationController
  layout 'water'

  def user
    @user=User.find_by_id(session[:user_id])
  end

     def cart
     user
     if @user
     @cart=Wcart.find :all,:conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     @cart_count=Wcart.count :conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     else
        @cart=Wcart.find :all,:conditions=>[' session_id=?',session.session_id]
        @cart_count=Wcart.count :conditions=>['session_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
      @cart_sum += cart.price*cart.wquantity if cart.wquantity
      @cart_sum += cart.price*cart.dquantity if cart.dquantity
     end

     end

       def del_cart
     user
     if @user
       Wcart.delete_all(['user_id=?',@user.id])
       Wcart.delete_all(['session_id=?',session.session_id])
     else
        Wcart.delete_all(['session_id=?',session.session_id])
     end
    redirect_to :action=>'edit_cart'
  end

   def del_cart_item
   
    cart_item=Wcart.find :first,:conditions=>['id=?',params[:id]]
    cart_item.destroy

    redirect_to :back
  end


 def create_cart
     user
    
    @cart_w = Wcart.new(params[:wcart])
   # @cart_w.save
   if @cart_w.water1_id
        @water = Water1.find_by_id(@cart_w.water1_id)
        if (@cart_w.water1_id == 1) or (@cart_w.water1_id == 2)

         @cart_w.price = @water.p1 if  ((@cart_w.wquantity >=3) and (@cart_w.wquantity <=5))
         @cart_w.price = @water.p2 if ((@cart_w.wquantity >=6) and (@cart_w.wquantity <=9))
         @cart_w.price = @water.p3 if ((@cart_w.wquantity >=10) and (@cart_w.wquantity <=20))
         @cart_w.price = @water.p4 if ((@cart_w.wquantity >=21) and (@cart_w.wquantity <=30))
         @cart_w.price = @water.p5 if (@cart_w.wquantity >30)
         @cart_w.save
   
          
        elsif @cart_w.water1_id == 3
         @cart_w.price = @water.p1  if ( @cart_w.wquantity == 1)
         @cart_w.price = @water.p2 if (@cart_w.wquantity == 2)
         @cart_w.price = @water.p3 if (@cart_w.wquantity >=3) and (@cart_w.wquantity <=5)
         @cart_w.price = @water.p4 if (@cart_w.wquantity >=6) and (@cart_w.wquantity <=10)
         @cart_w.price = @water.p5 if (@cart_w.wquantity >10)
         @cart_w.save
    
        end

        
        
   end
    @cart_w.save
    #redirect_to :action=>'edit_cart'
  end

  def create_cart2
     user

    @cart_w = Wcart.new(params[:wcart])
   # @cart_w.save
   if @cart_w.water1_id
        @water = Water1.find_by_id(@cart_w.water1_id)
        if (@cart_w.water1_id == 1) or (@cart_w.water1_id == 2)

         @cart_w.price = @water.p1 if  ((@cart_w.wquantity >=3) and (@cart_w.wquantity <=5))
         @cart_w.price = @water.p2 if ((@cart_w.wquantity >=6) and (@cart_w.wquantity <=9))
         @cart_w.price = @water.p3 if ((@cart_w.wquantity >=10) and (@cart_w.wquantity <=20))
         @cart_w.price = @water.p4 if ((@cart_w.wquantity >=21) and (@cart_w.wquantity <=30))
         @cart_w.price = @water.p5 if (@cart_w.wquantity >30)
         @cart_w.save


        elsif @cart_w.water1_id == 3
         @cart_w.price = @water.p1  if ( @cart_w.wquantity == 1)
         @cart_w.price = @water.p2 if (@cart_w.wquantity == 2)
         @cart_w.price = @water.p3 if (@cart_w.wquantity >=3) and (@cart_w.wquantity <=5)
         @cart_w.price = @water.p4 if (@cart_w.wquantity >=6) and (@cart_w.wquantity <=10)
         @cart_w.price = @water.p5 if (@cart_w.wquantity >10)
         @cart_w.save

        end



   end
    @cart_w.save
    #redirect_to :action=>'edit_cart'
  end



   def tov
    user
    cart
    
    @cat=Wdisp.find(params[:id])


  end

  def water
    user

    @water = Water1.find(:all)

  end

  def edit_cart
    user
    cart
   
  if params[:order]
   order=Worder.new(params[:order])
   
   flag=0
     for cart in @cart do
       flag+= cart.wquantity if cart.wquantity
       flag+= cart.dquantity if cart.dquantity
       order.liwater1 << Liwater1.new(:water1_id =>cart.water1_id ,:wdisp_id =>cart.wdisp_id , :price=>cart.price ,:wquantity =>cart.wquantity ,:dquantity =>cart.dquantity)
    end
    if flag >0
     if order.save
     
       Mailer.deliver_water1(order)
      Wcart.delete_all(['user_id=?',@user.id])
      Wcart.delete_all(['session_id=?',session.session_id])
        flash.now[:notice] = "Заказ отправлен"
        redirect_to :back
     else
       flash.now[:notice] = "Обязательно заполните поля: Имя и Телефон"

     end
    else
      redirect_to :action=>'no_ver'
    end
else
   if @cart_count == 0
     redirect_to :action=>'no_ver'
    end
end


  end

 

    def u1
    user


    Wcart.update(params[:cart].keys ,params[:cart].values)
    redirect_to :action =>'edit_cart'
   #  redirect_to :back
  end



def no_ver

end

  def disp
    user

    @wdisp = Wdisp.find(:all)
  end

  def dost
    
  end

end
