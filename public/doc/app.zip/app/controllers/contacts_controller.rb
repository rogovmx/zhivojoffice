class ContactsController < ApplicationController
 layout 'search'
  def index


  end

  def msk


  end

  def sml


  end



end
