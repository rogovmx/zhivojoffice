class Kt2Controller < ApplicationController

  layout 'search'

   require "will_paginate"
  def initialize
    @bestseller=Bestseller.find :all
    @sp=Ist.find:all


  end

  def user
    @user=User.find_by_id(session[:user_id])

 end
 def cart

     if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
        @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
       @cart_sum += cart.price*cart.quantity
     end

     end

  def  per_page
    
    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=20
    end
    return @per_page
  end

  def tg_n
    session[:original_uri]=request.request_uri
     user
     cart
     per_page



    order1=params[:order]
   if order1=='nd'
     order='name desc'
   elsif order1=='na'
     order='name asc'
   elsif order1=='pa'
     order='price asc'
   elsif order1=='pd'
     order='price desc'
   end

   filtr=params[:filtr]

      if (@user and  @user.role) != 'redaktor'

    if params[:filtr]==nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and vis=?',params[:id],1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=? and vis=?',params[:id],params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=? and vis=?',params[:id],params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and vis=?',params[:id],1], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       else
          if params[:filtr]==nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? ',params[:id]], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =?  and brend=?',params[:id],params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=?',params[:id],params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =?',params[:id]], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       end

   
    
  
  end

  def edit_tov_pod
       @cat1=Cat1.find(params[:id])
      render(:partial =>'/part/edit_tov_pod',:object=>@cat1)
   end


  def tg_n2
       session[:original_uri]=request.request_uri
     user
     cart
      @gr=Tov2.find(params[:id])
    @gr2=Tov3.find :all , :conditions=>['tov2_id=?',@gr.id],:order=>'ord'
    
         nn=0
 for gr in @gr2 do
      nn+=1
   @tg2 = Cat1.find :all, :conditions=>['tov3_id=? and vis=?',gr.id,1]
# @gr3=Tov3.find(:all,:conditions=> ["tov2_id=?",gr.id],:order=>'ord')
   if nn == 1
      @tgc = @tg2
       else
      @tgc = @tgc+@tg2
        end
        end
    
    
    per_page
    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=20
    end


      order1=params[:order]
   if order1=='nd'
     order='name desc'
   elsif order1=='na'
     order='name asc'
   elsif order1=='pa'
     order='price asc'
   elsif order1=='pd'
     order='price desc'
   end

   filtr=params[:filtr]

       if (@user and  @user.role) != 'redaktor'

    if params[:filtr]==nil and params[:order] ==nil
    @tg=@tgc.paginate :conditions=>['tg1=? and vis=?',1,1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
   elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=@tgc.paginate :conditions=>['tg1=? and brend=? and vis=?',1,params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=@tgc.paginate :conditions=>['tg1=? and brend=? and vis=?',1,params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=@tgc.paginate :conditions=>['tg1=? and vis=?',1,1], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       else
         if params[:filtr]==nil and params[:order] ==nil
     @tg=@tgc.paginate :conditions=>['tg1=?',1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=@tgc.paginate :conditions=>['tg1=? and brend=?',1,params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=@tgc.paginate :conditions=>['tg1=? and brend=?',1,params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=@tgc.paginate :conditions=>['tg1=?',1], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       end




  end


    def tg_n_p
       session[:original_uri]=request.request_uri
     user
     cart
     # @cat_tg=Cat1.find_by_sql('Select distingt ')
      @cat11=Cat1.find :all, :conditions=>['podarok=?',1],:group=>'tg'
    
    end

  def tg_v
    session[:original_uri]=request.request_uri
     user
     cart
     #per_page
     @per_page=session[:per_page]
    if @per_page==nil
      @per_page=12
    end
     
    order1=params[:order]
   if order1=='nd'
     order='name desc'
   elsif order1=='na'
     order='name asc'
   elsif order1=='pa'
     order='price asc'
   elsif order1=='pd'
     order='price desc'
   end

   filtr=params[:filtr]

       if (@user and  @user.role) != 'redaktor'

    if params[:filtr]==nil and params[:order] ==nil
    @tg=Cat1.paginate :conditions=>['tov3_id =?  and vis=?',params[:id],1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
   elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=? and vis=?',params[:id],params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =?  and brend=? and vis=?',params[:id],params[:filtr],1], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and vis=?',params[:id],1], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       else
         if params[:filtr]==nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? ',params[:id]], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]!=nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=?',params[:id],params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> order
    elsif  params[:filtr]!=nil and params[:order] ==nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? and brend=?',params[:id],params[:filtr]], :page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:filtr]==nil and params[:order] !=nil
     @tg=Cat1.paginate :conditions=>['tov3_id =? ',params[:id]], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       end


  end

end
