class CatalogsController < ApplicationController
  # GET /catalogs
  # GET /catalogs.xml
  def index
    @catalogs = Catalog.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @catalogs }
    end
  end

  # GET /catalogs/1
  # GET /catalogs/1.xml
  def show
    @catalogs = Catalog.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @catalogs }
    end
  end

  # GET /catalogs/new
  # GET /catalogs/new.xml
  def new
    @catalogs = Catalog.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @catalogs }
    end
  end

  # GET /catalogs/1/edit
  def edit
    @catalogs = Catalog.find(params[:id])
  end

  # POST /catalogs
  # POST /catalogs.xml
  def create
    @catalogs = Catalog.new(params[:catalogs])

    respond_to do |format|
      if @catalogs.save
        flash[:notice] = 'Catalogs was successfully created.'
        format.html { redirect_to(@catalogs) }
        format.xml  { render :xml => @catalogs, :status => :created, :location => @catalogs }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @catalogs.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /catalogs/1
  # PUT /catalogs/1.xml
  def update
    @catalogs = Catalog.find(params[:id])

    respond_to do |format|
      if @catalogs.update_attributes(params[:catalogs])
        flash[:notice] = 'Catalogs was successfully updated.'
        format.html { redirect_to(@catalogs) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @catalogs.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /catalogs/1
  # DELETE /catalogs/1.xml
  def destroy
    @catalogs = Catalog.find(params[:id])
    @catalogs.destroy

    respond_to do |format|
      format.html { redirect_to(catalogs_url) }
      format.xml  { head :ok }
    end
  end

  def gr
     gr3=params[:id]
    unless gr3
      gr3=35
    end
    gr3=params[:id]
    @gr1=G1.find(:all)
    @gr33=Cat.find(:all,:conditions=> ["g3_id=?",params[:id]])
    @gr75=Cat.find(:first,:conditions=>"g3_id='35'")
  end
  def tov
    render :text=>'drdddd'
  end
  def kanctov

  end
end
