class G2sController < ApplicationController
  # GET /g2s
  # GET /g2s.xml
  def index
    @g2s = G2.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @g2s }
    end
  end

  # GET /g2s/1
  # GET /g2s/1.xml
  def show
    @g2 = G2.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @g2 }
    end
  end

  # GET /g2s/new
  # GET /g2s/new.xml
  def new
    @g2 = G2.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @g2 }
    end
  end

  # GET /g2s/1/edit
  def edit
    @g2 = G2.find(params[:id])
  end

  # POST /g2s
  # POST /g2s.xml
  def create
    @g2 = G2.new(params[:g2])

    respond_to do |format|
      if @g2.save
        flash[:notice] = 'G2 was successfully created.'
        format.html { redirect_to(@g2) }
        format.xml  { render :xml => @g2, :status => :created, :location => @g2 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @g2.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /g2s/1
  # PUT /g2s/1.xml
  def update
    @g2 = G2.find(params[:id])

    respond_to do |format|
      if @g2.update_attributes(params[:g2])
        flash[:notice] = 'G2 was successfully updated.'
        format.html { redirect_to(@g2) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @g2.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /g2s/1
  # DELETE /g2s/1.xml
  def destroy
    @g2 = G2.find(params[:id])
    @g2.destroy

    respond_to do |format|
      format.html { redirect_to(g2s_url) }
      format.xml  { head :ok }
    end
  end
end
