class InfoController < ApplicationController
  layout 'bas1'


  def zakaz
    @menu=1
    @content=Statp.find :first, :conditions=>["title=?",'Как сделать заказ']

  end

  def dostavka
    @menu=2
    if session[:city]=='spb'
    @content=Statp.find :first, :conditions=>["title=?",'Условия доставки']
    elsif  session[:city]=='msk'
    @content=Statp.find :first, :conditions=>["title=?",'Условия доставки Москва']
    elsif  session[:city]=='smo'
    @content=Statp.find :first, :conditions=>["title=?",'Условия доставки Смоленск']
    elsif  session[:city]=='nn'
    @content=Statp.find :first, :conditions=>["title=?",'Условия доставки Нижний Новгород']
  end
  end

  def priem
    @menu=3
    @content=Statp.find :first, :conditions=>["title=?",'Как принимать товар']
  end

  def talon
    @menu=4
    @content=Statp.find :first, :conditions=>["title=?",'Гарантийные талоны']
  end

  def doci
    @menu=5
    @content=Statp.find :first, :conditions=>["title=?",'Шаблоны документов']
  end

  def shop
    @menu=6
    @content=Statp.find :first, :conditions=>["title=?",'Пользуйтесь интернет-магазином']
  end

end
