class KanctController < ApplicationController
  caches_page :idex
 def initialize
    @bestseller=Bestseller.find :all

    @sp=Ist.find:all
  end
  def index
    @k1=First1.find:all,:conditions=>"kod >100 and kod <200"
    #@k1=First1.find:all
    @k2=First1.find:all,:conditions=>"kod >200 and kod <300"
    @k3=First1.find:all,:conditions=>"kod >300"
  end

end
