class VdsController < ApplicationController
  # GET /vds
  # GET /vds.xml
  def index
    @vds = Vd.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @vds }
    end
  end

  # GET /vds/1
  # GET /vds/1.xml
  def show
    @vd = Vd.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @vd }
    end
  end

  # GET /vds/new
  # GET /vds/new.xml
  def new
    @vd = Vd.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @vd }
    end
  end

  # GET /vds/1/edit
  def edit
   #@vid=Vd.find(:all).map{|u| [u.Name,u.id]}
    @vid=Vd.find :first
    @vd = Vd.find(params[:id])
    
  end

  # POST /vds
  # POST /vds.xml
  def create
    @vd = Vd.new(params[:vd])

    respond_to do |format|
      if @vd.save
        flash[:notice] = 'Vd was successfully created.'
        format.html { redirect_to(@vd) }
        format.xml  { render :xml => @vd, :status => :created, :location => @vd }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @vd.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /vds/1
  # PUT /vds/1.xml
  def update
    @vd = Vd.find(params[:id])

    respond_to do |format|
      if @vd.update_attributes(params[:vd])
        flash[:notice] = 'Vd was successfully updated.'
       # redirect_to :controller=>'cabinet',:action=>'first4'
        #format.html { redirect_to :controller=>'cabinet',:action=>'first4' }
        format.html { redirect_to(@vd) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @vd.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /vds/1
  # DELETE /vds/1.xml
  def destroy
    @vd = Vd.find(params[:id])
    @vd.destroy

    respond_to do |format|
      format.html { redirect_to(vds_url) }
      format.xml  { head :ok }
    end
  end
end
