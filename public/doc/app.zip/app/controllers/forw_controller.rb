class ForwController < ApplicationController
  layout 'vvk_fw'
  def index

     user
    @ff1s = Ff1.find(:all)
    @forwarders = Forwarder.find(:all)
     @vote1s = Vote1.find(:all)
     #@vote1 = Vote1.new
  end


  def add_golos
     user
     @vote1=Vote1.new(params[:vote1s])
     @vote1.save
     redirect_to :action=>'index'
  end
def user
    @user=User.find_by_id(session[:user_id])

 end
def dropped
   user
  @ff1=Ff1.new
  @ff1.ff_id=4
  @ff1.user_id=9
  @ff1.ff_id=params[:f_id]
  @ff1.user_id=@user.id
  @ff1.todo=params[:todo]
  @ff1.save
   redirect_to :action=>'index'
end
   
end

