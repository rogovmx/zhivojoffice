class Cake1sController < ApplicationController
  # GET /cake1s
  # GET /cake1s.xml
  layout 'cake'
  require "will_paginate"

   def cake

  end

  def shef

  end

  def recipe

  end

  def price

  end

  def dost
    
  end

  def user
    @user=User.find_by_id(session[:user_id])
  end

   def cart
     user
     if @user
     @cart=Cakecart.find :all,:conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     @cart_count=Cakecart.count :conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     else
        @cart=Cakecart.find :all,:conditions=>[' session_id=?',session.session_id]
        @cart_count=Cakecart.count :conditions=>['session_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
       @cart_sum += cart.price*cart.quantity if cart.price
     end

     end

   def del_cart_item
    user
     cart_item=Cakecart.find :first,:conditions=>[' session_id=?',session.session_id]
     cart_item.destroy if cart_item
  end

   
 def create_cart
     user
      cart
      del_cart_item
        @cart_c = Cakecart.new(params[:cakecart])
     @cart_c.save
    # redirect_to :back
  end

    


     def u1
    user
        if @user
     cart_item=Cakecart.find :all,:conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     cart_item=Cakecart.count :conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     else
        cart_item=Cakecart.find :all,:conditions=>[' session_id=?',session.session_id]
        cart_item=Cakecart.count :conditions=>['session_id=?',session.session_id]
     end

    cart_item.destroy

    Cart.update(params[:cart].keys ,params[:cart].values)
    #redirect_to :action =>'edit_cart'
     redirect_to :back
  end

     def oc_cake

      @user=User.find_by_id(session[:user_id])
       if @user
     @cart=Cakecart.find :all,:conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     @cart_count=Cakecart.count :conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     else
       @cart=Cakecart.find :all,:conditions=>[' session_id=?',session.session_id]
        @cart_count=Cakecart.count :conditions=>['session_id=?',session.session_id]
     end

     @cart_sum=0
     @cart.each do |cart|
       @cart_sum+=cart.price*cart.quantity  if cart.price
     end


      render :partial=>'/cake1s/oc',:cart=>@cart

   end

   def no_ver
     
   end

   def order
   user
   cart
   end

   def order2
   user
   cart

    #@street=params[:adr_dost_id]
if params[:cake_order]
   order=Cakeorder1.new(params[:cake_order])
   #order.data_dost=params[:data_dost]
   flag=0
     for cart in @cart do
       flag+=cart.quantity
       order.licakeorder << Licakeorder.new(:cake1_id =>cart.cake1_id ,:filler1_id=>cart.filler1_id ,:quantity =>cart.quantity ,:weight=>cart.weight.to_i)
    end
    if flag >0
     if order.save
       flash.now[:notice] = "Заказ отправлен"
       Mailer.deliver_tort1(order)
       #redirect_to :action=>'index'
     else
       flash.now[:notice] = "Обязательно заполните поля: Имя и Телефон"
       #redirect_to :back
        # redirect_to :action=>'order'
     end
    else
      redirect_to :action=>'no_ver'
    end
     

  
  
  # Cart.delete_all(['user_id=?',@user.id])
  # Cart.delete_all(['sesion_id=?',session.session_id])
else
end
     end


  def index
    user
    cart
    @cake1s = Cake1.find(:all)
    @filler = Filler1.find(:all)
   
  end

  # GET /cake1s/1
  # GET /cake1s/1.xml
  def show
    user
    cart
    @cake = Cake1.find(params[:id])
    @filler = Filler1.find(:all)

   
  end

def pic1
 @cat=Cake1.find(params[:id])
 render :partial =>'/cake1s/pic1' , :object => @cat
 end

 def pic2
 @cat=Cake1.find(params[:id])
  render :partial =>'/cake1s/pic2' , :object => @cat
 end

  def new
    @cake1 = Cake1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @cake1 }
    end
  end


  def edit
    @cake1 = Cake1.find(params[:id])
  end

  def create
    @cake1 = Cake1.new(params[:cake1])

    respond_to do |format|
      if @cake1.save
        flash[:notice] = 'Cake1 was successfully created.'
        format.html { redirect_to(@cake1) }
        format.xml  { render :xml => @cake1, :status => :created, :location => @cake1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @cake1.errors, :status => :unprocessable_entity }
      end
    end
  end

  def update
    @cake1 = Cake1.find(params[:id])

    respond_to do |format|
      if @cake1.update_attributes(params[:cake1])
        flash[:notice] = 'Cake1 was successfully updated.'
        format.html { redirect_to(@cake1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @cake1.errors, :status => :unprocessable_entity }
      end
    end
  end


  def destroy
    @cake1 = Cake1.find(params[:id])
    @cake1.destroy

    respond_to do |format|
      format.html { redirect_to(cake1s_url) }
      format.xml  { head :ok }
    end
  end
end
