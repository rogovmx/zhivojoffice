class AtestController < ApplicationController
  def index

  end

end
