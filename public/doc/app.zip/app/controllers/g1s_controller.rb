class G1sController < ApplicationController
  # GET /g1s
  # GET /g1s.xml
  def index
    @g1s = G1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @g1s }
    end
  end

  # GET /g1s/1
  # GET /g1s/1.xml
  def show
    @g1 = G1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @g1 }
    end
  end

  # GET /g1s/new
  # GET /g1s/new.xml
  def new
    @g1 = G1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @g1 }
    end
  end

  # GET /g1s/1/edit
  def edit
    @g1 = G1.find(params[:id])
  end

  # POST /g1s
  # POST /g1s.xml
  def create
    @g1 = G1.new(params[:g1])

    respond_to do |format|
      if @g1.save
        flash[:notice] = 'G1 was successfully created.'
        format.html { redirect_to(@g1) }
        format.xml  { render :xml => @g1, :status => :created, :location => @g1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @g1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /g1s/1
  # PUT /g1s/1.xml
  def update
    @g1 = G1.find(params[:id])

    respond_to do |format|
      if @g1.update_attributes(params[:g1])
        flash[:notice] = 'G1 was successfully updated.'
        format.html { redirect_to(@g1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @g1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /g1s/1
  # DELETE /g1s/1.xml
  def destroy
    @g1 = G1.find(params[:id])
    @g1.destroy

    respond_to do |format|
      format.html { redirect_to(g1s_url) }
      format.xml  { head :ok }
    end
  end
end
