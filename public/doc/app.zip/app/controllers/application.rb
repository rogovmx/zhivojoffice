# Filters added to this controller apply to all controllers in the application.
# Likewise, all the methods added will be available for all controllers.

class ApplicationController < ActionController::Base
  helper :all # include all helpers, all the time


  
  # See ActionController::RequestForgeryProtection for details
  # Uncomment the :secret if you're not using the cookie session store
  protect_from_forgery  :secret => '53f7d51f5d9cc3fa021b9c1c26b37e8c'
  
  # See ActionController::Base for details 
  # Uncomment this to filter the contents of submitted sensitive data parameters
  # from your application log (in this case, all fields with names like "password"). 
  # filter_parameter_logging :password

  private
  def uri_f
    #session[:original_uri]=request.request_uri
    # @uri=session[:original_uri]
     #@uri=request.request_uri
  end
  



   def authorize
     unless User.find_by_id(session[:user_id])
       session[:original_uri]=request.request_uri
     
     redirect_to(:controller=>'login',:action=>'login')
     end
   end

   def admin_s
      @user=User.find_by_id(session[:user_id])
      unless @user.role=='admin_s'
        redirect_to :controller=>'er_admin'
      end
   end

   def redaktor
      @user=User.find_by_id(session[:user_id])
      unless (@user.role=='redaktor' or @user.role=='sredaktor')
        redirect_to :controller=>'er_admin'
      end
   end

   def admin_bonus
      @user=User.find_by_id(session[:user_id])
      unless @user.role=='bonus'
        redirect_to :controller=>'er_admin'
      end
   end
    def admin_call
      @user=User.find_by_id(session[:user_id])
      unless @user.role=='callcentr'
        redirect_to :controller=>'er_admin'
      end
   end

    def mess
      @user=User.find_by_id(session[:user_id])
      unless @user.role=='mess'
        redirect_to :controller=>'er_admin'
      end
   end
   def manager
      @user=User.find_by_id(session[:user_id])
      unless @user.role=='manager'
        redirect_to :controller=>'er_admin'
      end
   end
end
