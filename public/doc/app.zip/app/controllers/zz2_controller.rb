class Zz2Controller < ApplicationController
  layout 'vvk'

  def new
    zz1=Zz1.new(params[:zz1])
    zz1.save
    Mailer.deliver_zz(zz1.phone,zz1.name,zz1.quest,zz1.m)
    render:text=>'Наш оператор свяжется с Вами.'
  end

def index
  @manager=Manager1.find :all


end

end
