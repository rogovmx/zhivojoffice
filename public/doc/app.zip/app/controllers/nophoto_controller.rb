class NophotoController < ApplicationController
layout 'search_nofoot'
before_filter:authorize
before_filter :redaktor

require "will_paginate"

  def index


    @np=Cat1.paginate :conditions=>["(pic1 like ? or pic1 is ?) and vis=?",'',nil,1],  :page=>params[:page] , :per_page=>100, :order=>'tov3_id'
  end

end
