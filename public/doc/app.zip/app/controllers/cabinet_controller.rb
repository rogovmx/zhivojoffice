class CabinetController < ApplicationController
  #layout 'kanct_admin'
    #layout 'l_o1'

    layout 'search'
    before_filter :authorize
    require "will_paginate"
  def user
  @user=User.find_by_id(session[:user_id])
  @user_name =@user.scr_name
  @user_fam =@user.surname
  @user_mail= @user.mail
  @user_tel=@user.phone
  @gruup=@user.company
  @client=@user.client1_id

  end



                     
  def show_cab
    user
   render :update do |page|
     if @user.role =='admin_s'
      page.replace_html( 'l_cab', :partial=>'/part2/uk_menu' )
     elsif @user.role =='bonus'
      page.replace_html( 'l_cab', :partial=>'/part2/bonus_menu' )
     elsif @user.role =='manager'
      page.replace_html( 'l_cab', :partial=>'/part2/manager_menu' )
     elsif (@user.role=='redaktor' or @user.role=='sredaktor')
      page.replace_html( 'l_cab', :partial=>'/part2/redaktor_menu' )
     elsif @user.role == 'callcentr'
      page.replace_html( 'l_cab', :partial=>'/part2/callcentr_menu' )
     elsif @user.role=='poduser'
      page.replace_html( 'l_cab', :partial=>'/part2/poduser_menu' )
     else
       page.replace_html( 'l_cab', :partial=>'/part2/cab_menu' )
     end
    page.visual_effect(:blind_down, 'l_cab', :duration=> 0.2)
   end
  end

   def per_page
    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=20
    end
    return @per_page
  end


  def index
    redirect_to :action=>'reg_data'
  #  user
   #@order=Order.find:all,:conditions=>['client_id=?',@client]

  end

  def feedback
     user
    @menu=8
   @name = 'обратная связь'
    if request.post?

      feedback = Feedback.new(params[:feedback])
      feedback.save
      flash[:notice] = 'Сообщение отправлено'
       Mailer.deliver_feedback(feedback)
    end

  end


  def order
     user
   @menu=4
   @name = 'заказы'
  #   @order=Order.paginate :all,:conditions=>['client_id=?',@client],:page => params[:page] , :per_page =>10
    if @client == 0
    @order=Order.paginate :all,:conditions=>['user_id=?',@user.id],:page => params[:page] , :per_page =>15 , :order=>'created_at desc'
    else
    @order=Order.paginate :all,:conditions=>['user_id=? or client_id=?',@user.id,@client],:page => params[:page] , :per_page =>15 , :order=>'created_at desc'
    end
  end


  def allorders
    user
    @menu=4
   @name = 'Все заказы'
    if @client == 0
    @order=Order.find :all,:conditions=>['user_id=?',@user.id], :order=>'created_at desc'
    else
    @order=Order.find :all,:conditions=>['user_id=? or client_id=?',@user.id,@client] , :order=>'created_at desc'
    end
    @cat=[]
    @lineall=[]
    for order in @order do
    @line=Lineitem.find :all,:conditions=>['order_id=?',order.id] , :select=>'distinct k1c'
    @lineall+=@line
    end
    @lineall.map!{|x| x.k1c.strip}.uniq!
    for line in @lineall do
    @tmp=Cat1.find :first , :conditions=>['k1c=? and vis=?', line, 1]
    @cat << @tmp if @tmp
    end
    
    
    @cat.sort!{|a,b| a[:tov3_id] <=> b[:tov3_id] }

    @tg=@cat.paginate :page => params[:page], :per_page =>@per_page
  end


  def order_details
    @order=Order.find(params[:id])
     @line=Lineitem.find :all,:conditions=>['order_id=?',@order.id]
    render :partial=>'details',:object=>@line ,:object=>@order
  end

   def konkursorder_details
    @order=Konkursorder.find(params[:id])
     @line=Konkursitem.find :all,:conditions=>['konkursorder_id=?',@order.id]
    render :partial=>'konkursdetails',:object=>@line ,:object=>@order
  end

  def first
    user
    if @client
      redirect_to :action=>'index'
    else
       @vid=Vd.find(:all).map{|u| [u.Name,u.id]}
    end
  end


  def first1
    user
    @client=Client.new(params[:client])
    @client.save

    @user.client_id=@client.id
    @user.save
    
  end

  def client
    user
    @client_full=Client.find(@client)
  return @client_full
  end

  def first2
      user
      client
    @legal=Legal.new(params[:legal])
    @legal.client_id=@client
    @legal.save
  end


   def first21
     user
     client
    
  end


   def first22
      user
      client
    @legal=Legal.new(params[:legal])
    @legal.client_id=@client
    @legal.save
    redirect_to :controller=>'bas1',:action=>'oz'
  end

  def first3
    user
    client
    @adr_dost=AdrDost.new(params[:adr_dost])
    @adr_dost.client_id=@client_full.id
    @adr_dost.save
    redirect_to :action=>'first4'
  end


  def first31
    user
    client
  end
 def first32
    user
    client
    @adr_dost=AdrDost.new(params[:adr_dost])
    @adr_dost.client_id=@client_full.id
    @adr_dost.save
    redirect_to :controller=>'bas1',:action=>'oz'
  end


 def reg_data
    #user
      @user=User.find_by_id(session[:user_id])
      @client=@user.client1_id
      @menu=1
      @name = 'регистрационные данные'

   # client
   # @vd=Vd.find(:first,:conditions=>['id=?',@client_full.vid_id])
  #  @legal=Legal.find(:all,:conditions=>['client_id=?',@client_full.id])
   # @adr_dost=AdrDost.find(:all,:conditions=>['client_id=?',@client_full.id])
 end

 def favorits
   user
   @menu=2
   @name = 'избранные товары'
   session[:original_uri]=request.request_uri
    per_page
 

#   if params[:brend]== nil and params[:tg1] == nil
    
    @it_tov=It.find(:all,:conditions=>["user_id=?",@user.id])

    @it_tov.each do |it|
      tmp=Cat1.find :first , :conditions=>["k1c=? and vis=?",it.k1c , 1]
      it.destroy unless tmp
    end

    @it_tov=It.paginate(:all,:conditions=>["user_id=?",@user.id],:page => params[:page], :per_page =>@per_page,:order=>'created_at DESC' )
  
#   elsif  params[:tg1] == nil
#   @it_tov=It.paginate :all,:conditions=>["user_id=? and brend=?", @user.id,params[:brend]],:page => params[:page], :per_page =>@per_page
#   elsif params[:brend] == nil
#    @it_tov=It.paginate :all,:conditions=>["user_id=? and tg1=?", @user.id,params[:tg1]],:page => params[:page], :per_page =>@per_page
#   end
 end


 def it1
    user
   @it=It.find(:all,:conditions=>["user_id=? and tg1=?",@user.id,params[:tg1]])
 end

 def delete_it
   user
    uri=session[:original_uri]
   
   @it=It.find(:first,:conditions=>['user_id=? and k1c=?',@user.id,params[:k1c]])
   @it.destroy
   #redirect_to :controller=>'cabinet',:action=>'it'
   redirect_to(uri || {:controller=>'kt1'})
end
 def tov_spec
   user
  @menu=3
   @name = 'договора и спецификации'
   session[:original_uri]=request.request_uri
    #per_page
    @per_page=20
   #@it=It.find(:all,:conditions=>['user_id=?',@user.id])
    #@it1=It.find_by_sql(["select distinct name from first1s where user_id=? and kod < 200",@user.id])
   @it1=TovSpec.find_by_sql(["select distinct tg1 from tov_specs where legal_id=? and kod_f1<200",@user.client_id])
   @it1_count=TovSpec.count :conditions=>["legal_id=? and kod_f1<200",@user.id]
   @it2=TovSpec.find_by_sql(["select distinct tg1 from tov_specs where legal_id=? and kod_f1 >200 and kod_f1<300",@user.client_id])
   @it2_count=TovSpec.count :conditions=>["legal_id=? and kod_f1 > 200 and kod_f1<300",@user.client_id]
   @it3=TovSpec.find_by_sql(["select distinct tg1 from tov_specs where legal_id=? and kod_f1>300",@user.client_id])
   @it3_count=TovSpec.count :conditions=>["legal_id=? and kod_f1 > 300",@user.client_id]
   @brend=TovSpec.find_by_sql(["select distinct brend from tov_specs where legal_id=?",@user.client_id])


   if params[:brend]== nil and params[:tg1] == nil
   @it_tov=TovSpec.paginate(:all,:conditions=>["legal_id=?",@user.client_id],:page => params[:page], :per_page =>@per_page,:order=>'created_at DESC' )
   elsif  params[:tg1] == nil
   @it_tov=TovSpec.paginate :all,:conditions=>["legal_id=? and brend=?", @user.client_id,params[:brend]],:page => params[:page], :per_page =>@per_page
   elsif params[:brend] == nil
    @it_tov=TovSpec.paginate :all,:conditions=>["legal_id=? and tg1=?", @user.client_id,params[:tg1]],:page => params[:page], :per_page =>@per_page
   end


   ##################
   #user
   #@tov_spec=TovSpec.find(:all,:conditions=>['user_id=?',@user.id])
 end


 def sotr
   user
     @menu=6
   @name = 'сотрудники'
  @sotr=User.find :all ,:conditions=>["client1_id=? and role2=? ",@user.client1_id,'poduser',]
  
 end

 def del_sotr
   @del=User.find(params[:id])
   @del.destroy
   redirect_to :action=>'sotr'

 end




 def poduser_cart
    user
     @sotr=User.find(params[:sotr])
   @cart=Cart.find :all,:conditions=>['User1_id=? ',@sotr.id]
   #render :text=>params[:user]
   render :partial=>'poduser',:cart=>@cart ,:user=>@user ,:sotr=>@sotr

 end

 def zka
    user
   @order=Lineitem.find_by_sql("select distinct order_id  from lineitems where user1_id="+ @user.id.to_s)
 end

 def order_details_poduser
   user
    @order=Order.find(params[:id])
     @line=Lineitem.find :all,:conditions=>['order_id=? and user1_id=?',@order.id,@user.id]
    render :partial=>'details_poduser',:object=>@line ,:obbject=>@order
  end


 def chpass
  @user=User.find_by_id(session[:user_id])
  if @user.update_attributes(params[:user11])
  else
  end
    redirect_to :controller=>'cabinet',:action=>'reg_data'
 end

def edit_sotr

  @user=User.find_by_id(params[:id])
  if request.post? and @user.update_attributes(params[:user11])
 
  
      flash.now[:notice] = "Пользователь #{@user.name} сохранен"
      rnd=rand(999999999999999999999999999999999999999999)
      conf=Confirm.new
      conf.user_id=@user.id
      conf.rnd=rnd
      conf.save
      Mailer.deliver_welcome(@user.mail,@user.scr_name,@user.name,@user.password,@user.surname,@user.phone,rnd)
     redirect_to :controller=>'cabinet',:action=>'sotr'
    end

end

def edit_user
@name='редактирование пользователя'
@menu=1
@user=User.find_by_id(session[:user_id])
  #  respond_to do |format|
   #   if @user.update_attributes(params[:user11])
       # u_crm(@user_id)
    #    flash[:notice] = 'User was successfully updated.'
     #    format.html { redirect_to :controller=>'call1' }
       # format.html { redirect_to(@user) }
      #  format.xml  { head :ok }
    #  else
     #   format.html { render :action => "edit" }
      #  format.xml  { render :xml => @user.errors, :status => :unprocessable_entity }
    #  end
  #  end
  end
def edit_pass
  @user=User.find_by_id(session[:user_id])
  @name='изменение пароля'
@menu=1
end

def konkurs
user
@name='задания на конкурс'
@menu=7

@order=Konkursorder.find:all,:conditions=>['client_id=?',@client]

end

def to_cart
  user
 @order=Order.find(params[:id])
@line=Lineitem.find :all,:conditions=>['order_id=?',@order.id]

@line.each do |line|
  @uprice=Nprice1.find_by_k1c(line.k1c)
  @cat=Cat1.find :first ,:conditions=>['k1c=? and vis=?', line.k1c, 1]
  @cart=Cart.new(:Sesion_id=>session.session_id, :otdel=> "kanc" , :User_id=>@user.id, :k1s=> line.k1c, :price=> @uprice.pp , :user1_id=>@user.id) if @cat
  @cart.save
end
redirect_to :back

end


end
