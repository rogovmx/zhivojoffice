class Kt3Controller < ApplicationController
  layout 'vvk'

   require "will_paginate"
  def initialize
    @bestseller=Bestseller.find :all
    @sp=Ist.find:all
  end


  def user
    @user=User.find_by_id(session[:user_id])
  end

 def cart
     user
     if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
        @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
       @cart_sum += cart.price*cart.quantity if cart.price
     end

     end


  def  per_page

    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=20
    end
    return @per_page
  end

  def sale3m
     session[:original_uri]=request.request_uri
     user
     cart
     #per_page
     @per_page=session[:per_page]
    if @per_page==nil
      @per_page=21
    end

    order1=params[:order]
   if order1=='nd'
     order='name desc'
   elsif order1=='na'
     order='name asc'
   elsif order1=='pa'
     order='price asc'
   elsif order1=='pd'
     order='price desc'
   end

  # filtr=params[:filtr]

  search = '3m'
       if (@user and  @user.role) != 'redaktor'




    if params[:order] ==nil
     @tg=Cat1.paginate :conditions=>["(name like ?  or brend like ?  or subbrend like ? or tg like ? )and vis=?",'%'+search+'%','%'+search+'%','%'+search+'%','%'+search+'%',1],:page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:order] !=nil
     @tg=Cat1.paginate :conditions=>["(name like ?  or brend like ?  or subbrend like ? or tg like ? )and vis=?",'%'+search+'%','%'+search+'%','%'+search+'%','%'+search+'%',1], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       else
          if params[:order] ==nil
     @tg=Cat1.paginate :conditions=>["(name like ?  or brend like ?  or subbrend like ? or tg like ? )",'%'+search+'%','%'+search+'%','%'+search+'%','%'+search+'%'],:page => params[:page], :per_page =>@per_page,:order=> 'portg'
    elsif  params[:order] !=nil
     @tg=Cat1.paginate :conditions=>["(name like ?  or brend like ?  or subbrend like ? or tg like ? )",'%'+search+'%','%'+search+'%','%'+search+'%','%'+search+'%'], :page => params[:page], :per_page =>@per_page,:order=> order
    end
       end

  end


   def summer
     session[:original_uri]=request.request_uri
     user
     cart
     #per_page
     #@per_page=session[:per_page]
    if @per_page==nil
      @per_page=15
    end
    @all = Monitoring.find(:all)
#    ff=0
#    @all.each do |all|
#      ff+=1
#     @tovar = all if  ff==1
#     @tovar = @tovar + all
#    end

#          if params[:order] ==nil
#     @tg= @tovar.paginate :all,:page => params[:page], :per_page =>@per_page
#    elsif  params[:order] !=nil
#     @tg= @tovar.paginate :all, :page => params[:page], :per_page =>@per_page
#    end
    
       render :layout=>'vvk_summer'
  end



  def tg_v
     session[:original_uri]=request.request_uri
     user
     cart
     #per_page
     @per_page=session[:per_page]
    if @per_page==nil
      @per_page=12
    end
 @btg=Btg1.find :first , :conditions=>['tg=?', params[:id]]
 
 if @user and @user.role == 'redaktor'
 @cat1s=Cat1.find :all , :conditions=>['tov3_id=?',params[:id]], :order=>'price'
 else
 @cat1s=Cat1.find :all , :conditions=>['vis=? and tov3_id=? and not(name like ?)',1,params[:id],'%'+'АКЦИЯ'+'%'] , :order=>'price'
 @act=Cat1.find :all , :conditions=>['vis=? and tov3_id=? and name like ?',1,params[:id],'%'+'АКЦИЯ'+'%'] , :order=>'price'
 end


   
   if params[:order]=='nd'
   @cat1s.sort!{|a,b| b[:name] <=> a[:name]}
   elsif params[:order]=='na'
   @cat1s.sort!{|a,b| a[:name] <=> b[:name]}
   elsif params[:order]=='pd'
   @cat1s.sort!{|a,b| b[:price] <=> a[:price]}
   else
   @cat1s.sort!{|a,b| a[:price] <=> b[:price]}  
   end


  @cat1s=@act+@cat1s if @act and @act.size != 0 and session[:city] != 'smo'


 unless params[:btg]
session[:filtr]={}

    if params[:filtr]==nil
     @tg=@cat1s.paginate :page => params[:page], :per_page =>@per_page
    elsif  params[:filtr]!=nil 
     @tg=@cat1s.find_all{|a| a[:brend] == params[:filtr]}.paginate :page => params[:page], :per_page =>@per_page
    end

 else

if params[:del]
session[:filtr].delete(params[:s])
redirect_to :action=>'tg_v', :id=>params[:id] if session[:filtr].size == 0
else      
session[:filtr].merge!({params[:s] => params[:har]})
end

@goods2=@cat1s
@keys=session[:filtr].keys

      
for n in @keys do
btg_s_find(params[:btg],n,session[:filtr][n])

#if (@goods2 & @goods).size != 0
@goods2 &= @goods
flash[:notice] = "С данным набором характеристик товаров нет." if @goods2.size==0
#else
#session[:filtr].delete(n)
#end
end

@tg=@goods2.paginate  :page => params[:page], :per_page =>@per_page
 end
end

 def btg_s_find(btg,par_s,har)

   @bcat=Bcat1.find :all , :conditions=>['btg1_id=?',btg]
   @tov=@bcat.map{|b|  b[:s1] if b.send('s'+par_s)==har}.compact
    @goods=[]
       for tov in @tov do
        @good=Cat1.find :first , :conditions=>['k1c=? and vis=?',tov,1] if tov
        @goods<<@good if @good
      end

 end

  def tg_v2
     session[:original_uri]=request.request_uri
     user
     cart
     @tgv2=1
      #@k=First1.find(:first,:conditions=> ["kod=?",params[:id]])
      @gr=Tov2.find(params[:id])
      @gr2=Tov3.find :all , :conditions=>['tov2_id=?',@gr.id],:order=>'ord', :select=>'id'
      @tgc=[]
      @act=[]
 for gr in @gr2 do
   if @user and  @user.role == 'redaktor'
   @tg2 = Cat1.find :all, :conditions=>['tov3_id=?',gr.id]
   @act1=[]
   else

   @act1=Cat1.find :all , :conditions=>['tov3_id=? and vis=? and name like ?',gr.id, 1,'%'+'АКЦИЯ'+'%'], :order=>'price'
   @tg2 = Cat1.find :all, :conditions=>['tov3_id=? and vis=? and not(name like ?)',gr.id, 1 ,'%'+'АКЦИЯ'+'%'], :order=>'price'
   end
   @tgc += @tg2 unless @tg2.empty?
   @act += @act1 unless @act1.empty?
end


    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=18
    end

if params[:order]=='pa'  or params[:order]==nil
  @tgc.sort!{|a,b| a[:price] <=> b[:price]}
   elsif params[:order]=='nd'
  @tgc.sort!{|a,b| b[:name] <=> a[:name]}
   elsif params[:order]=='na'
  @tgc.sort!{|a,b| a[:name] <=> b[:name]}
   elsif params[:order]=='pd'
  @tgc.sort!{|a,b| b[:price] <=> a[:price]}
end
@tgc=@act+@tgc if @act and @act.size != 0 and session[:city] != 'smo'

    if params[:filtr]==nil
     @tg=@tgc.paginate :page => params[:page], :per_page =>@per_page
    elsif  params[:filtr]!=nil
     @tg=@tgc.find_all{|a| a[:brend] == params[:filtr]}.paginate :page => params[:page], :per_page =>@per_page
    end

  end

 def tg_n
    session[:original_uri]=request.request_uri
     user
     cart
     per_page
@btg=Btg1.find :first , :conditions=>['tg=?', params[:id]]

 if @user and @user.role == 'redaktor'
 @cat1s=Cat1.find :all , :conditions=>['tov3_id=?',params[:id]], :order=>'price'
 else
 @cat1s=Cat1.find :all , :conditions=>['vis=? and tov3_id=? and not(name like ?)',1,params[:id],'%'+'АКЦИЯ'+'%'] , :order=>'price'
 @act=Cat1.find :all , :conditions=>['vis=? and tov3_id=? and name like ?',1,params[:id],'%'+'АКЦИЯ'+'%'] , :order=>'price'
 end



   if params[:order]=='nd'
   @cat1s.sort!{|a,b| b[:name] <=> a[:name]}
   elsif params[:order]=='na'
   @cat1s.sort!{|a,b| a[:name] <=> b[:name]}
   elsif params[:order]=='pd'
   @cat1s.sort!{|a,b| b[:price] <=> a[:price]}
   else
   @cat1s.sort!{|a,b| a[:price] <=> b[:price]}
   end


  @cat1s=@act+@cat1s if @act and @act.size != 0 and session[:city] != 'smo'


 unless params[:btg]
session[:filtr]={}

    if params[:filtr]==nil
     @tg=@cat1s.paginate :page => params[:page], :per_page =>@per_page
    elsif  params[:filtr]!=nil
     @tg=@cat1s.find_all{|a| a[:brend] == params[:filtr]}.paginate :page => params[:page], :per_page =>@per_page
    end

 else

if params[:del]
session[:filtr].delete(params[:s])
redirect_to :action=>'tg_v' , :id=>params[:id] if session[:filtr].size == 0
else
session[:filtr].merge!({params[:s] => params[:har]})
end

@goods2=@cat1s
@keys=session[:filtr].keys


for n in @keys do
btg_s_find(params[:btg],n,session[:filtr][n])

#if (@goods2 & @goods).size != 0
@goods2 &= @goods
flash[:notice] = "С данным набором характеристик товаров нет." if @goods2.size==0
#else
#session[:filtr].delete(n)
#end
end

@tg=@goods2.paginate  :page => params[:page], :per_page =>@per_page
 end
  end


   def tg_n2
       session[:original_uri]=request.request_uri
     user
     cart
     @tgn=1
     @tgn2=1

      @gr=Tov2.find(params[:id])
      @gr2=Tov3.find :all , :conditions=>['tov2_id=?',@gr.id],:order=>'ord', :select=>'id'
      @tgc=[]
      @act=[]
 for gr in @gr2 do
   if @user and  @user.role == 'redaktor'
   @tg2 = Cat1.find :all, :conditions=>['tov3_id=?',gr.id]
   @act1=[]
   else
   @act1=Cat1.find :all , :conditions=>['tov3_id=? and vis=? and name like ?',gr.id, 1,'%'+'АКЦИЯ'+'%'], :order=>'price'
   @tg2 = Cat1.find :all, :conditions=>['tov3_id=? and vis=? and not(name like ?)',gr.id, 1 ,'%'+'АКЦИЯ'+'%'], :order=>'price'
   end
   @tgc += @tg2 unless @tg2.empty?
   @act += @act1 unless @act1.empty?
end
    per_page


if params[:order]=='pa'  or params[:order]==nil
  @tgc.sort!{|a,b| a[:price] <=> b[:price]}
   elsif params[:order]=='nd'
  @tgc.sort!{|a,b| b[:name] <=> a[:name]}
   elsif params[:order]=='na'
  @tgc.sort!{|a,b| a[:name] <=> b[:name]}
   elsif params[:order]=='pd'
  @tgc.sort!{|a,b| b[:price] <=> a[:price]}
end
@tgc=@act+@tgc if @act.size != 0 and session[:city] != 'smo'
   if params[:filtr]==nil
     @tg=@tgc.paginate :page => params[:page], :per_page =>@per_page
    elsif  params[:filtr]!=nil
     @tg=@tgc.find_all{|a| a[:brend] == params[:filtr]}.paginate :page => params[:page], :per_page =>@per_page
    end

  end




   def create_cart
     user
     @all_c = Cart.find :all
     if @user
     @exist = Cart.find :first , :conditions=>['k1s=? and (User_id=? or Sesion_id=?)' , params[:cart2][:k1s], @user.id, session.session_id] if params[:cart2]
     @exist = Cart.find :first , :conditions=>['k1s=?and (User_id=? or Sesion_id=?)' , params[:cart][:k1s], @user.id, session.session_id] if params[:cart]
     else
      @exist = Cart.find :first , :conditions=>['k1s=? and  Sesion_id=?' , params[:cart2][:k1s], session.session_id] if params[:cart2]
     @exist = Cart.find :first , :conditions=>['k1s=?and Sesion_id=?' , params[:cart][:k1s], session.session_id] if params[:cart]
     end

       if @exist
       @exist.quantity += params[:cart][:quantity].to_i if params[:cart]
       @exist.quantity += params[:cart2][:quantity].to_i if params[:cart2]
       @exist.save
     else


    @cart = Cart.new(params[:cart2]) if params[:cart2]
    @cart = Cart.new(params[:cart]) if params[:cart]
    @cart.quantity = 1 if @cart.quantity == nil or @cart.quantity == '' or @cart.quantity == ' '
     @cart.save
      end
   end

   def tov
    user
    cart
    $num=0
    @cat=Cat1.find(params[:id])

  if @cat and !@cat.vis
  if Tov3.find(@cat.tov3_id).vis
  redirect_to(:action => 'tg_v' , :id=>@cat.tov3_id)
  else
  redirect_to '/'
  end
  end
  
    if @cat and @cat.st

    @cat2=Cat1.find(@cat.st)
      if @cat2 and @cat2.vis
         params[:st] = '1'
      else 
         params[:st] = '0'
      end
    else
      params[:st] = '0'
    end
   @picts=[@cat.pic1]
     for pic in @cat.cat1img do
       @picts<<pic.pic
     end
@s_tov=[]
@tg=[]
if @cat and @cat.st
  tcat=@cat.st
  #1.upto(20) do
  loop do
  @tmp=Cat1.find_by_id(tcat)
   unless @tmp or tcat
     @s_tov=[]
     break
   end
   if @tmp and @s_tov.include?(@tmp.id)
   break
   end
  if @tmp
  @s_tov<<@tmp.id
  tcat=@tmp.st
  end
  end

  unless @s_tov.empty?
  @s_tov.uniq! 
  @s_tov-= @cat.id.to_a
  for s_tov in @s_tov do
  @find=Cat1.find :first, :conditions=>['id=? and vis=? and k11!=?',s_tov,1,999]
  @tg<<@find if @find
  end
  end
end
     #@t_pict=[@cat.pic1, @cat.pic2, @cat.pic3].delete_if { |pp| pp==''  }
     #@pict=@t_pict.compact

  end

 def pic1
 @pic=params[:pic]
 render :partial =>'/part/pic1' , :pic => @pic
 end

  def pic2
 #@num=params[:num].to_i
 $num+=1 if params[:next]=='1'
 $num-=1 if params[:next]=='-1'
 @cat=Cat1.find(params[:cat])
 @picts=[@cat.pic1]
     for pic in @cat.cat1img do
       @picts<<pic.pic
     end
 @pic=@picts[$num]
 $num=0 unless @pic
 @pic=@picts[$num]
 render :partial =>'/part/pic1' , :pic => @pic , :object=>$num
 end

 

   def kanc1
     user
     session[:original_uri]=request.request_uri
    cart
     @k=First1.find(:first,:conditions=> ["kod=?",params[:id]])
    unless read_fragment(:fragment=>'kt3kanc1')
     #@k=First1.find(:first,:conditions=> ["kod=?",params[:id]])
    @gr2=Tov2.find(:all,:conditions=> ["first1_id=?",@k.id],:order=>'ord')

    end
   end


   def oc(id)
     if id==nil
     @st=0
      else

      @cat1=Cat1.find(id)
      @st=Cat1.find :first , :conditions=>['id=?',@cat1.st]
      #@st=@cat1.st
     end
      @user=User.find_by_id(session[:user_id])
       if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
       @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum_bonus=0
     @cart_bonus=Cart.find :all,:conditions=>[' sesion_id=? and otdel != ?',session.session_id,'raspr']

     @cart_bonus.each do |cart1|
       @cart_sum_bonus+=cart1.price*cart1.quantity if cart1.price
     end
     @cart_sum=0
     @cart.each do |cart|
       @cart_sum+=cart.price*cart.quantity if cart.price
     end


      render :partial=>'/part/oc',:cart=>@cart , :st=>@st

   end

   def oc1

     @st=0


      @user=User.find_by_id(session[:user_id])
       if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
       @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum_bonus=0
     @cart_bonus=Cart.find :all,:conditions=>[' sesion_id=? and otdel != ?',session.session_id,'raspr']

     @cart_bonus.each do |cart1|
       @cart_sum_bonus+=cart1.price*cart1.quantity if cart1.price
     end
     @cart_sum=0
     @cart.each do |cart|
       @cart_sum+=cart.price*cart.quantity if cart.price
     end


      render :partial=>'/part2/oc',:cart=>@cart

   end

    def del_tov
    Cat1.destroy(params[:id])
    redirect_to :back
  end

    def kt3_spec
      @cat=Cat1.find(params[:id])
      render(:partial =>'kt3_spec',:object=>@cat)
   end

     def kt3_st
      @cat=Cat1.find(params[:id])
      render(:partial =>'kt3_st',:object=>@cat)
   end

   def show_menu1

    if params[:kod] == '1'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >100 and kod <200" ,:order=>'kod'
    @name='Бумага и изделия из бумаги'
    elsif params[:kod] == '2'
    @k=First1.find:all,:select=>"name ,kod , id",:conditions=>"kod >200 and kod <300" ,:order=>'kod'
    @name='Хранение документов'
    elsif params[:kod] == '3'
    @k=First1.find:all,:select=>"name ,kod , id",:conditions=>"kod >300 and kod <400",:order=>'kod'
    @name='Канцелярские принадлежности'
    elsif params[:kod] == '4'
    @k=First1.find:all,:select=>"name ,kod , id",:conditions=>"kod >400 and kod <500" ,:order=>'kod'
    @name='Письменные приналежности'
    elsif params[:kod] == '5'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >500 and kod <600" ,:order=>'kod'
    @name='Компьютеры и аксессуары'
    elsif params[:kod] == '6'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >600 and kod <700" ,:order=>'kod'
    @name='Оргтехника'
    elsif params[:kod] == '7'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >700 and kod <800" ,:order=>'kod'
    @name='Бытовая техника'
    elsif params[:kod] == '8'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >800 and kod <900" ,:order=>'kod'
    @name='Интерьер'
    elsif params[:kod] == '9'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >900 and kod <1000" ,:order=>'kod'
    @name='Продукты'
    elsif params[:kod] == '10'
    @k=First1.find:all,:select=>"name ,kod, id",:conditions=>"kod >1000 and kod <1100" ,:order=>'kod'
    @name='Товары для офисной жизни'
    end

     unless params[:all]
     render :update do |page|
       page.replace_html( 'left_menu2', :partial=>'/part2/left_menu2' ,:kod=>params[:kod] )
       page.replace_html( 'left_submenu', :partial=>'/part2/left_submenu' ,:k=>@k , :name=>@name )
       page.visual_effect(:blind_down, 'left_submenu', :duration=> 0.4)
     end
     else
       render :update do |page|
       page.replace_html( 'all_cont', :partial=>'/part2/all_cont' )
       page.replace_html( 'left_menu2', :partial=>'/part2/left_menu2' ,:kod=>params[:kod] )
       page.replace_html( 'left_submenu', :partial=>'/part2/left_submenu' ,:k=>@k , :name=>@name )
       page.visual_effect(:blind_down, 'all_cont', :duration=> 0.2)
     end

     end


   end

   def sale
 session[:original_uri]=request.request_uri
     user
     cart
     per_page

      if (@user and  @user.role) != 'redaktor'
     @tg=Cat1.paginate :conditions=>['vis=? and raspr=?' ,1,1], :page => params[:page], :per_page =>@per_page,:order=> 'price'
        else
     @tg=Cat1.paginate :conditions=>['raspr=?' ,1], :page => params[:page], :per_page =>@per_page,:order=> 'price'
        end
   end


      def sale_v
 #session[:original_uri]=request.request_uri
     user
     cart
     per_page

  if (@user and  @user.role) != 'redaktor'
     @tg=Cat1.paginate :conditions=>['vis=? and raspr=?' ,1,1], :page => params[:page], :per_page =>@per_page,:order=> 'price'
          else
     @tg=Cat1.paginate :conditions=>['raspr=?' ,1], :page => params[:page], :per_page =>@per_page,:order=> 'price'
          end
   end



#def msk_sale
#      msk_sale_v
#end
#
#
#def msk_sale_v
#user
#redirect_to '/' if session[:city] != 'msk'  or (@user and @user.city!='Москва' and @user.role != 'redaktor')
# #session[:original_uri]=request.request_uri
#cart
#per_page
#
#       @msk=Moskov.all
#       @tmp=[]
#       for msk in @msk do
#       @cat=Cat1.find :first , :conditions=>['k1c=?',msk.k1c]
#       @tmp<<@cat if @cat
#       end
#
#@tg=@tmp.paginate :page => params[:page], :per_page =>@per_page,:order=> 'price'
#end


#def msk_paper
#     user
#
#redirect_to '/' if session[:city] != 'msk' and session[:city] != 'spb' or (@user and ((@user.city!='Москва' or @user.city!='Санкт-Петербург') and @user.role != 'redaktor') )
#
# #session[:original_uri]=request.request_uri
#       cart
#       per_page
#
#       @msk=Mskpaper.all
#       @tmp=[]
#       for msk in @msk do
#       @cat=Cat1.find :first , :conditions=>['k1c=?',msk.k1c]
#       @tmp<<@cat if @cat
#       end
#     @tmp.sort!{|a,b| a[:price]<=>b[:price]}
#     @tg=@tmp.paginate :page => params[:page], :per_page =>@per_page,:order=> 'price'
#end
#
#
#def msk_paper_v
#msk_paper
#end


  def gifts
    user
    cart
    per_page
    @gift1=[]
    for gift in Gift.all do
      tmp=Cat1.find :first , :conditions=>['k1c=?',gift.k1c]
      @gift1<<tmp if tmp
    end

     if params[:order]=='pa' or params[:order]=='nil'
     @gift1.sort!{|a,b| a[:price]<=>b[:price]}
     elsif params[:order]=='pd'
     @gift1.sort!{|a,b| b[:price]<=>a[:price]}
     elsif params[:order]=='na'
     @gift1.sort!{|a,b| a[:name]<=>b[:name]}
     elsif params[:order]=='nd'
     @gift1.sort!{|a,b| b[:name]<=>a[:name]}
     end

     @tg=@gift1.paginate :page => params[:page], :per_page =>@per_page

  end


end
