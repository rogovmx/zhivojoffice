class TcontentController < ApplicationController
  def index
  end

end
