class G3sController < ApplicationController
  # GET /g3s
  # GET /g3s.xml
  def index
    @g3s = G3.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @g3s }
    end
  end

  # GET /g3s/1
  # GET /g3s/1.xml
  def show
    @g3 = G3.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @g3 }
    end
  end

  # GET /g3s/new
  # GET /g3s/new.xml
  def new
    @g3 = G3.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @g3 }
    end
  end

  # GET /g3s/1/edit
  def edit
    @g3 = G3.find(params[:id])
  end

  # POST /g3s
  # POST /g3s.xml
  def create
    @g3 = G3.new(params[:g3])

    respond_to do |format|
      if @g3.save
        flash[:notice] = 'G3 was successfully created.'
        format.html { redirect_to(@g3) }
        format.xml  { render :xml => @g3, :status => :created, :location => @g3 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @g3.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /g3s/1
  # PUT /g3s/1.xml
  def update
    @g3 = G3.find(params[:id])

    respond_to do |format|
      if @g3.update_attributes(params[:g3])
        flash[:notice] = 'G3 was successfully updated.'
        format.html { redirect_to(@g3) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @g3.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /g3s/1
  # DELETE /g3s/1.xml
  def destroy
    @g3 = G3.find(params[:id])
    @g3.destroy

    respond_to do |format|
      format.html { redirect_to(g3s_url) }
      format.xml  { head :ok }
    end
  end
end
