class Bonus2Controller < ApplicationController
require "will_paginate"


  def index
    session[:original_uri]=request.request_uri
    @per_page=20
       @user=User.find_by_id(session[:user_id])
    if @user
      if @user.city == 'Санкт-Петербург' or @user.city == nil
      @bonus=Bonus3.paginate :all, :conditions=>['spb=?',1] ,:page => params[:page],:per_page => @per_page,:order=>'number'
      elsif @user.city=='Москва'
      @bonus=Bonus3.paginate :all, :conditions=>['msk=?',1] ,:page => params[:page],:per_page => @per_page,:order=>'number'
      elsif @user.city=='Смоленск'
      @bonus=Bonus3.paginate :all, :conditions=>['smo=?',1] ,:page => params[:page],:per_page => @per_page,:order=>'number'
      end

    else
     @bonus=Bonus3.paginate :all,:page => params[:page],:per_page => @per_page,:order=>'number'
    end



    if @user
     @summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])

     @count1=Bcart1.count(:conditions=> ["user_id=?",@user.id])
     @client=Client.find :first ,:conditions=>["id=?",@user.client1_id]

      #cl= @client.k1c
      #cl1=cl.strip
      @bonus_many=Bonus1.find :first, :conditions=>["k1c=?",@client.k1c] if @client

      if @bonus_many
      @limit=@bonus_many.ost-@summ
      @count=3-@count1
      else
       @limit=0
        @count=0
      end
    end
  end

  def bonus_tov
     @user=User.find_by_id(session[:user_id])
   if @user
     @summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])

     @count1=Bcart1.count(:conditions=> ["user_id=?",@user.id])
     @client=Client.find :first ,:conditions=>["id=?",@user.client1_id]
      cl= @client.k1c
      cl1=cl.strip
      @bonus_many=Bonus1.find :first, :conditions=>["k1c=?",@client.k1c]
      if @bonus_many
      @limit=@bonus_many.ost-@summ
      @count=3-@count1
      else
       @limit=0
        @count=0
      end
    end
    
    @bonus=Bonus3.find(params[:id])

     end
  def rule
   @user=User.find_by_id(session[:user_id])
   if @user
     @summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])

     @count1=Bcart1.count(:conditions=> ["user_id=?",@user.id])
     @client=Client.find :first ,:conditions=>["id=?",@user.client1_id]
      #cl= @client.k1c
      #cl1=cl.strip
      @bonus_many=Bonus1.find :first, :conditions=>["k1c=?",@client.k1c] if @client
      if @bonus_many
      @limit=@bonus_many.ost-@summ
      @count=3-@count1
      else
       @limit=0
        @count=0
      end
    end
  end

  def create_bonus_cart
    
    @user=User.find_by_id(session[:user_id])
    @summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])
    @count1=Bcart1.count(:conditions=> ["user_id=?",@user.id])
    @limit=0-@summ
    @count=3-@count1
    @cart=Bcart1.new
    @cart.user_id=@user.id
    @cart.k1c=params[:k1c]
    @cart.bonus_price=params[:price]
    @cart.save
   
    redirect_to :back
    #@card=Bcart1.find(:all ,:conditions=> ["user_id=?",@user.id])
    
    
  end
  def editcart
     @user=User.find_by_id(session[:user_id])
   if @user
     @summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])

     @count1=Bcart1.count(:conditions=> ["user_id=?",@user.id])
     @client=Client.find :first ,:conditions=>["id=?",@user.client1_id]
      cl= @client.k1c
      cl1=cl.strip
      @bonus_many=Bonus1.find :first, :conditions=>["k1c=?",@client.k1c]
      if @bonus_many
      @limit=@bonus_many.ost-@summ
      @count=3-@count1
      else
       @limit=0
        @count=0
      end
    end

       
     @cart=Bcart1.find(:all ,:conditions=> ["user_id=?",@user.id])

  end

  def del_bon
    @user=User.find_by_id(session[:user_id])
     Bcart1.delete(params[:id])
     redirect_to :controller=>'bonus2',:action=>'editcart'
  end

  def delcart
     @user=User.find_by_id(session[:user_id])
    Bcart1.delete_all(['user_id=?',@user.id])
     #Cart.delete_all(['User_id=?',@user.id])
    redirect_to :controller=>'bonus2'
  end

  def  send_bonus
   @user=User.find_by_id(params[:id])
   @client=Client.find :first ,:conditions=>["id=?",@user.client_id]
   order=Bcart1.find(:all ,:conditions=> ["user_id=?",@user.id])
   #k1c=@client.k1c
   #client=@client.name
   #Mailer.deliver_zbonus(order,k1c,client)
   Mailer.deliver_zbonus(order)
   @bonus_many=Bonus1.find :first, :conditions=>["k1c=?",@client.k1c]
   summ=Bcart1.sum(:bonus_price,:conditions=> ["user_id=?",@user.id])
   ost=@bonus_many.ost
   @bonus_many.ost=ost - summ
   @bonus_many.save
   Bcart1.delete_all(['user_id=?',@user.id])
   redirect_to :action=>'index'
  end

end
