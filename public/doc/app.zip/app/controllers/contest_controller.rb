class ContestController < ApplicationController
    layout 'vvk_fw'

  def index
    user
    @konkurs = Konkurs1.find(:all)
  end

  def showcont
    user
 
  @konkurs = Konkurs1.find(params[:id])
  @konkursimg = Konkursimg.find :all , :conditions=>['konkurs1_id = ?' , params[:id]]
  end


    def add_golos
     user
     @vote1=Vote1.new(params[:vote1s])
     @vote1.save
     redirect_to :action=>'index'
  end
def user
    @user=User.find_by_id(session[:user_id])

 end

end
