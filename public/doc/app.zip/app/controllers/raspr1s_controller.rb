class Raspr1sController < ApplicationController
  layout 'vvk'
 require "will_paginate"
  # GET /raspr1s
  # GET /raspr1s.xml
  def index
    @raspr1s = Raspr1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @raspr1s }
    end
  end

  # GET /raspr1s/1
  # GET /raspr1s/1.xml
  def show
    @raspr1 = Raspr1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @raspr1 }
    end
  end

  # GET /raspr1s/new
  # GET /raspr1s/new.xml
  def new
    @raspr1 = Raspr1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @raspr1 }
    end
  end

  # GET /raspr1s/1/edit
  def edit
    @raspr1 = Raspr1.find(params[:id])
  end

  # POST /raspr1s
  # POST /raspr1s.xml
  def create
    @raspr1 = Raspr1.new(params[:raspr1])

    respond_to do |format|
      if @raspr1.save
        flash[:notice] = 'Raspr1 was successfully created.'
        format.html { redirect_to(@raspr1) }
        format.xml  { render :xml => @raspr1, :status => :created, :location => @raspr1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @raspr1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /raspr1s/1
  # PUT /raspr1s/1.xml
  def update
    @raspr1 = Raspr1.find(params[:id])

    respond_to do |format|
      if @raspr1.update_attributes(params[:raspr1])
        flash[:notice] = 'Raspr1 was successfully updated.'
        format.html { redirect_to(@raspr1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @raspr1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /raspr1s/1
  # DELETE /raspr1s/1.xml
  def destroy
    @raspr1 = Raspr1.find(params[:id])
    @raspr1.destroy

    respond_to do |format|
      format.html { redirect_to(raspr1s_url) }
      format.xml  { head :ok }
    end
  end
end
