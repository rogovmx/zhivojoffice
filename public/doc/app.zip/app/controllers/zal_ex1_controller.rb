class ZalEx1Controller < ApplicationController
 require 'fileutils'
  require "parseexcel"
  
  def index
    file=params[:file]
    @un=''
    exel=Spreadsheet::ParseExcel.parse('public/data/'+file)
    #exel=Spreadsheet::ParseExcel.parse('public/ex1/opis22.xls')
worksheet = exel.worksheet(0,0)
 i=0
 @ssss =Array.new
worksheet.each { |row|

 i+=1
  if row != nil
  if  i==1
    ii=0
    row.each { |cell|
      ii+=1
    if ii == 3

     # contents = cell.to_s('Windows-1251')
     contents = cell.to_s('UTF-8')
      contents1=contents.strip
      @un=contents1

      #puts "Row: #{j} Cell: #{i} #{contents1}"
    end
    i = i+1
  }
  else
   ss1=Array.new
 iii=0
  row.each { |cell|
 iii+=1
    if cell != nil
      if iii==1
        k1c=cell.to_s('UTF-8')
        ss1[0]=k1c
      end
      if iii==2
        name=cell.to_s('UTF-8')
        ss1[1]=name
      end
      if iii==3


      contents = cell.to_s('UTF-8')
      opis=contents.delete("\n")
      ss1[2]=opis
     
      end
        
      #puts "Row: #{j} Cell: #{i} #{contents1}"
    end
    @ssss << ss1
    # cat1=Cat1.find(:first,:conditions=>["k1c=?",k1c])
    # if cat1
     #cat1.opis=opis
     #cat1.save
    #end
  }



  end
  end
  @ii=i
}
   File.delete('public/data/'+file)
  end
##############################
    ##############################
##############################
  def zal_b
     file=params[:file]
     exel=Spreadsheet::ParseExcel.parse('public/data/'+file)
     worksheet = exel.worksheet(0,0)
     uu=0
     worksheet.each { |row|

  uu+=1
  if row != nil
   if uu==1
   else
            
 #######################################
        ii=0
        cat1=Cat1.new
  row.each { |cell|
    
          ii+=1
    if cell != nil

            if ii==1
              contents = cell.to_s('UTF-8')
              cat1.tov3_id=contents
            elsif ii==2
              contents = cell.to_s('UTF-8')
              cat1.k1c=contents
            elsif ii==3
              contents = cell.to_s('UTF-8')
              contents1=contents.delete("\n")
              cat1.tg=contents1
            elsif ii==4
              contents = cell.to_s('UTF-8')
              cat1.portg=contents
            elsif ii==5
              contents = cell.to_s('UTF-8')
              cat1.tg1=contents
            elsif ii==6
              contents = cell.to_s('UTF-8')
              contents1=contents.delete("\n")
              cat1.name=contents1
            end

    end

  }
  cat1.save
   end
####################################################################
  end

}
@uu=uu-1
 File.delete('public/data/'+file)
  end

end
