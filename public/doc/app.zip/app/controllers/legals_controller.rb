class LegalsController < ApplicationController
  # GET /legals
  # GET /legals.xml
  #layout 'spens1'
 # layout 'kanct_admin'
 layout 'l_o1'
   before_filter :authorize
  def index
    @legals = Legal.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @legals }
    end
  end

  # GET /legals/1
  # GET /legals/1.xml
  def show
    @legal = Legal.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @legal }
    end
  end

  # GET /legals/new
  # GET /legals/new.xml
  def new
    @legal = Legal.new
    @client=params[:client]
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @legal }
    end
  end

  # GET /legals/1/edit
  def edit
    @legal = Legal.find(params[:id])
  end

  # POST /legals
  # POST /legals.xml
  def create
    @legal = Legal.new(params[:legal])

    respond_to do |format|
      if @legal.save
        flash[:notice] = 'Legal was successfully created.'
       
         format.html { redirect_to :controller=>'cabinet',:action=>'first4' }
        #format.html { redirect_to(@legal) }
        format.xml  { render :xml => @legal, :status => :created, :location => @legal }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @legal.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /legals/1
  # PUT /legals/1.xml
  def update
    @legal = Legal.find(params[:id])

    respond_to do |format|
      if @legal.update_attributes(params[:legal])
        flash[:notice] = 'Legal was successfully updated.'
        legal_crm(@legal.id)
         format.html { redirect_to :controller=>'cabinet',:action=>'first4' }
        #format.html { redirect_to(@legal) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @legal.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /legals/1
  # DELETE /legals/1.xml
  def destroy
    @legal = Legal.find(params[:id])
    @legal.destroy

    respond_to do |format|
      format.html { redirect_to(legals_url) }
      format.xml  { head :ok }
    end
  end

  def legal_crm(id)
       @legal=Legal.find(params[:id])
       @legal_crm=LegalCrm.new
       @legal_crm.legal_id=@legal.id
       @legal_crm.name=@legal.name
       @legal_crm.ofp=@legal.ofp
       @legal_crm.inn=@legal.inn
       @legal_crm.kpp=@legal.kpp
       @legal_crm.ps=@legal.ps
       @legal_crm.bank_id=@legal.bank_id
       @legal_crm.ubp=@legal.ubp
       @legal_crm.status=@legal.status
       @legal_crm.client_id=@legal.client_id
       @legal_crm.save
  end

end
