class First3sController < ApplicationController
  # GET /first3s
  # GET /first3s.xml
  def index
    @first3s = First3.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @first3s }
    end
  end

  # GET /first3s/1
  # GET /first3s/1.xml
  def show
    @first3 = First3.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @first3 }
    end
  end

  # GET /first3s/new
  # GET /first3s/new.xml
  def new
    @first3 = First3.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @first3 }
    end
  end

  # GET /first3s/1/edit
  def edit
    @first3 = First3.find(params[:id])
  end

  # POST /first3s
  # POST /first3s.xml
  def create
    @first3 = First3.new(params[:first3])

    respond_to do |format|
      if @first3.save
        flash[:notice] = 'First3 was successfully created.'
        format.html { redirect_to(@first3) }
        format.xml  { render :xml => @first3, :status => :created, :location => @first3 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @first3.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /first3s/1
  # PUT /first3s/1.xml
  def update
    @first3 = First3.find(params[:id])

    respond_to do |format|
      if @first3.update_attributes(params[:first3])
        flash[:notice] = 'First3 was successfully updated.'
        format.html { redirect_to(@first3) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @first3.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /first3s/1
  # DELETE /first3s/1.xml
  def destroy
    @first3 = First3.find(params[:id])
    @first3.destroy

    respond_to do |format|
      format.html { redirect_to(first3s_url) }
      format.xml  { head :ok }
    end
  end
end
