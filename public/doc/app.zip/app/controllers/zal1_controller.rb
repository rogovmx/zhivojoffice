class Zal1Controller < ApplicationController
  
   require 'iconv'
   require 'fileutils'
before_filter :authorize
before_filter :redaktor
 def initialize
 
 end

  def index

 
  end
def  spl
  file=params[:file]
  colline=0
   IO.foreach('public/'+ file) do |line|
     colline+=1
     if  colline ==1
       @say1=1
     else
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
  
   ss1=ss.split(";")
   cat=Catalog.new
   cat.k1c=ss1[0]#код1с
   cat.kpk=ss1[1]#код печ каталога
   cat.kkom=ss1[2]#комус
   cat.kkont=ss1[3]#конторинг
   cat.kprog=ss1[4]#прогматик
   cat.artpr=ss1[5]#артикул произв
   cat.name=ss1[6]#полное имя
   #tg
   cat.kg1=ss1[7]#код гр1
   cat.g1=ss1[8]#название группы
   cat.kzs=ss1[9]#код заглавной страницы сайта
   cat.kg2=ss1[10]#код гр2
   cat.g2=ss1[11]# название гр2
   cat.kg3=ss1[12]#код гр3
   cat.g3=ss1[13]#название гр 3
   cat.color=ss1[14]#цвет
   cat.format=ss1[15]#формат
   cat.kl=ss1[16]#количество листов
   cat.ktver=ss1[17]#твердость
   cat.brend=ss1[18]#бренд
   cat.subbrend=ss1[19]#суббренд
   cat.pic1=ss1[20]#рис1
   cat.pic2=ss1[21]#рис2
  cat.opis=ss1[22]#описание
   cat.ei=ss1[23]#ед изм
   cat.price=ss1[24]#цена
   cat.tu=ss1[25]#транспортная упаковка
   cat.pricetu=ss1[26]#цена за транспортную упаковку
   cat.save

    @ok=file
     end
end
    
end
def del

 # G1.delete_all()
 # G2.destroy_all()
 # G3.destroy_all()
 # Cat.destroy_all()
   redirect_to :controller=>'kt'
end
def delgrupp
  #Tov2.delete_all()
  #Tov3.destroy_all()

   redirect_to :controller=>'kt'
end
def zalgrupp
  colline=0
  file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
      if colline==1

      else
        converter=Iconv.new('UTF-8','Windows-1251')
        ss=converter.iconv(line)
        ss1=ss.split(";")

        @f1=First1.find(:first,:conditions=>["kod=?",ss1[0]])
        @tov2=Tov2.find(:first,:conditions=>["first1_id=?",@f1.id])
        unless @tov2
          tov2=Tov2.new
          tov2.first1_id=@f1.id
          tov2.name=ss1[1]
          tov2.ord=ss1[2]
          tov2.save
        end
        @tov21=Tov2.find(:first,:conditions=>["name=?",ss1[1]])
         unless @tov21
          tov2=Tov2.new
          tov2.first1_id=@f1.id
          tov2.name=ss1[1]
          tov2.ord=ss1[2]
          tov2.save
        end
        @tov22=Tov2.find(:first,:conditions=>["name=?",ss1[1]])
          tov3=Tov3.new
          tov3.tov2_id=@tov22.id
          tov3.name=ss1[3]
          tov3.ord=ss1[4]
          tov3.save
         
      end
     #  redirect_to :controller=>'first1s'
   end


end
 def zalcat
   
   ll=0
   lll=0
   colline=0
   file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
    if colline==1

    else

  # IO.foreach('public/Spens.csv') do |line|
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   
   @g1=G1.find(:first,:conditions=>["kod=?",ss1[8]])
   unless @g1
     g11=G1.new
     g11.kod=ss1[8]
     g11.name=ss1[9]
     g11.save
     lll+=1
     
   end
   @g1=G1.find(:first,:conditions=>["kod=?",ss1[8]])
     ll+=1
     
    @g2=G2.find(:first,:conditions=>["kod=? and name=?",ss1[11],ss1[12]])
    unless @g2
      g22=G2.new
      g22.g1_id=@g1.id
      g22.kod=ss1[11]
      g22.kzs=ss1[10]
      g22.name=ss1[12]
      g22.save
      
    end
      @g2=G2.find(:first,:conditions=>["kod=? and name=?",ss1[11],ss1[12]])
   
    @g3=G3.find(:first,:conditions=>["name=?",ss1[14]])
    unless @g3
      g33=G3.new
      g33.g2_id=@g2.id
      g33.name=ss1[14]
      g33.save
     
    end
     @g3=G3.find(:first,:conditions=>["name=?",ss1[14]])
    cat=Cat.new
    cat.g3_id=@g3.id
    cat.k1c=ss1[0]
    cat.kpk=ss1[1]
    cat.kkom=ss1[2]
    cat.kkont=ss1[3]
    cat.kprod=ss1[4]
    cat.arppr=ss1[5]
    cat.name=ss1[6]
    cat.tg=ss1[7]
    cat.color=ss1[15]
    cat.format=ss1[16]
    cat.kl=ss1[17]
    cat.ktver=ss1[18]
    cat.brend=ss1[19]
    cat.subbrend=ss1[20]
    cat.pic1=ss1[21]
    cat.pic2=ss1[22]
    cat.opis=ss1[23]
    cat.ei=ss1[24]
    cat.price=ss1[25]
    cat.tu=ss1[26]
    cat.pricetu=ss1[27]
    cat.tg1=ss1[28]
    cat.save
   end

   end

   @say=ll
   @say1=lll
   @g11=G1.find(:all)
   redirect_to :controller=>'kt1'
   
 end


 def zalcat1_old
    ll=0
   lll=0
   colline=0
   file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
     if colline==1

     else
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   cat=Cat1.find(:first,:conditions=>["k1c=?",ss1[1]])
   if cat==nil
     cat1=Cat1.new
   else
     cat1=cat
   end

   cat1.tov3_id=ss1[0]
    cat1.k1c=ss1[1]
    cat1.kpk=ss1[2]
    cat1.kkom=ss1[3]
    cat1.kkont=ss1[4]
    cat1.kprog=ss1[5]
    cat1.arppr=ss1[6]
    cat1.tg=ss1[7]
    cat1.portg=ss1[8]
    cat1.name=ss1[9]
    cat1.o1s=ss1[10]
    cat1.o2s=ss1[11]
    cat1.o3s=ss1[12]
    cat1.color=ss1[13]
    cat1.format=ss1[14]
    cat1.kl=ss1[15]
    cat1.ktv=ss1[16]
    cat1.kpl=ss1[17]
    cat1.kzap=ss1[18]
    cat1.kmod=ss1[19]
    cat1.kves=ss1[20]
    cat1.brend=ss1[21]
    cat1.subbrend=ss1[22]
    cat1.pic1=ss1[23]
    cat1.pic2=ss1[24]
    cat1.opis=ss1[25]
    cat1.ei=ss1[26]
    cat1.price=ss1[27]
    cat1.tu=ss1[28]
    cat1.pricetu=ss1[29]
    cat1.tg1=ss1[30]
    cat1.save
     end
   end
    File.delete('public/data/'+file)
   redirect_to :controller=>'kt1'
 end

 ################
  def zalcat1
    ll=0
   lll=0
   colline=0
   file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
     if colline==1

     else
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   cat=Cat1.find(:first,:conditions=>["k1c=?",ss1[1]])
   if cat==nil
     cat1=Cat1.new
   else
     cat1=cat
   end

   cat1.tov3_id=ss1[0]
    cat1.k1c=ss1[1]
    cat1.tg=ss1[2]
    cat1.portg=ss1[3]
    cat1.tg1=ss1[4]
    cat1.name=ss1[5]
  
    
    cat1.save
     end
   end
    File.delete('public/data/'+file)
   redirect_to :controller=>'kt1'
 end

 ##################


 def zal_price11
  colline=0
  un=''
  kkkk=Array.new
  kkkk.clear
   file=params[:file]
   IO.foreach('public/data/'+file) do |line|
     colline+=1
     if colline==1
converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss11=ss.split(";")
   un=ss11[1]
     else
   converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
  
   cat1=Cat1.find(:first,:conditions=>["k1c=?",ss1[0]])
   
 if cat1==nil
  # ss1[0] >>k1c
 # k1c << ss1[0]
   kkkk[colline-2]=ss1[0]

   else
     #cat1=cat
 


    cat1.k1c=ss1[0]

    cat1.price=ss1[1]
   
    cat1.save
     end
    end
   end
   File.delete('public/data/'+file)
   #ss=k1c.nitems
   kkkk.compact
   ss=kkkk.length
   

   if ss==0

   flash[:notice]="Цены  успешно обновленны!"
   redirect_to :back
   else
    flash[:notice]="Были ошибки!"
    @k1c=kkkk
   
   end
 end

 #==============
  #def zal_univer1
  def zal_price474747
  colline=0
  kkkk=Array.new
  kkkk.clear
  cc1=''
   file=params[:file]
   IO.foreach('public/data/'+file) do |line|
     colline+=1
    
     if colline==1

     
   #converter=Iconv.new('UTF-8','Windows-1251')
   #ss=converter.iconv(line)
   #ss1=ss.split(";")
   ss1=line.split(";")
    @un1=ss1[1]
    @un3=colline
    cc1= @un1

    @un5=cc1.class
 #  if  ss1[1]=='1'
 if cc1 =='1'

      @un4='444'
     @un='price'
    
  
 end

     else
   
    end
   end


   IO.foreach('public/data/'+file) do |line|
     colline+=1
     if colline==1

     else
      converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")

   cat1=Cat1.find(:first,:conditions=>["k1c=?",ss1[0]])

 if cat1==nil
  # ss1[0] >>k1c
 # k1c << ss1[0]
   kkkk[colline-2]=ss1[0]

   else
     #cat1=cat



    cat1.k1c=ss1[0]

  cat1.price=ss1[1] if @un=='price'
     
  
    cat1.save

     end
    end
   end
   File.delete('public/data/'+file)
   #ss=k1c.nitems
   kkkk.compact
   ss=kkkk.length


   if ss==0

   flash[:notice]="Цены  успешно обновленны!"
   redirect_to :back
   else
    flash[:notice]="Были ошибки!"
    @k1c=kkkk
  
   end
 end


 #==============

 def zal_price
  colline=0
  colerr=0
  ErUploadUniver.destroy_all()
  error1= ErUploadUniver.new
   file=params[:file]
   get_val(file)
   IO.foreach('public/data/'+file) do |line|
     colline+=1
     if colline==1

     else
   converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   ss1[0].chomp
   cat1=Cat1.find(:first,:conditions=>["k1c=?",ss1[0]])

    if cat1==nil
    colerr+=1
    ss00=ss1[0].to_s
    ss01=ss1[1].to_s
   
   
  error1.k1c=ss00
  error1.name=ss01
 


  error1.save

   else
   
    cat1.k1c=ss1[0]
    
    if @un=="price"
    cat1.price=ss1[2]
    elsif @un=="pic1"
    cat1.pic1=ss1[2]
      elsif @un=="pic2"
    cat1.pic2=ss1[2]
      elsif @un=="pricetu"
    cat1.pricetu=ss1[2]
      elsif @un=="tu"
    cat1.tu=ss1[2]
     elsif @un=="kpk"
    cat1.kpk=ss1[2].chomp!
    elsif @un=="kkom"
    cat1.kkom=ss1[2]
    elsif @un=="kkont"
    cat1.kkont=ss1[2]
    elsif @un=="kprag"
    cat1.kprog=ss1[2]
     elsif @un=="arpr"
    cat1.arppr=ss1[2]
     elsif @un=="name"
    cat1.name=ss1[2]
     elsif @un=="color"
    cat1.color=ss1[2]
     elsif @un=="format"
    cat1.format=ss1[2]
     elsif @un=="kl"
    cat1.kl=ss1[2]
    elsif @un=="brend"
    cat1.brend=ss1[2]
    elsif @un=="subbrend"
    cat1.subbrend=ss1[2]
    elsif @un=="opis"
    cat1.opis=ss1[2]
    elsif @un=="ei"
    cat1.ei=ss1[2]
    elsif @un=="ktv"
    cat1.ktv=ss1[2]
     elsif @un=="o1s"
    cat1.o1s=ss1[2]
     elsif @un=="o2s"
    cat1.o2s=ss1[2]
     elsif @un=="o3s"
    cat1.o3s=ss1[2]
     elsif @un=="kpl"
    cat1.kpl=ss1[2]
     elsif @un=="kzap"
    cat1.kzap=ss1[2]
    elsif @un=="kmod"
    cat1.kmod=ss1[2]
   elsif @un=="kves"
    cat1.kves=ss1[2]
   elsif @un=="old_price"
    cat1.old_price=ss1[2]
    else
    
    end
    cat1.save
     end
    end
   end
   File.delete('public/data/'+file)
   #ss=k1c.nitems
   er=ErUploadUniver.count
   unless er ==0
     @err=ErUploadUniver.find:all
     @cc=colline
     @cr=colerr
   else
     redirect_to :back
   end



  
   
 end

def get_val(file)
  colline=0
   IO.foreach('public/data/'+file) do |line|
     colline+=1
   #  converter=Iconv.new('UTF-8','Windows-1251')
  # ss=converter.iconv(line)
   ss11=line.split(";")
   un=ss11[2]
   @un=un.chomp
   break
   end
  return @un
end


 def zal_bonus
  colline=0
  colline1=0
   file=params[:file]
   BonusEr.destroy_all()
     IO.foreach('public/data/'+file) do |line|
        colline1+=1
         if colline1==1

     else
       ss=line.split(";")
       if ss.length!=11 or ss[0]==''
         br=BonusEr.new
         br.str=colline1
         if ss.length!=11
         br.er='Количество полей'
         end
         if ss[0]==''
         br.er='Пустой код 1С'
         end
         br.save
         end
         end
     end
     er=BonusEr.count
      unless er==0
        @err=BonusEr.find(:all)
         File.delete('public/data/'+file)
      else

  
   IO.foreach('public/data/'+file) do |line|
     colline+=1
     if colline==1

     else
   converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")

   bonus1=Bonus1.find(:first,:conditions=>["k1c=?",ss1[0]])

 if bonus1==nil
     bonus=Bonus1.new
     bonus.k1c=ss1[0]
     bonus.kd=ss1[1]
     bonus.bonus_id=ss1[2]
     bonus.ost=ss1[10]
     bonus.save
      Mailer.deliver_bonus(ss1[6],ss1[4],ss1[5],ss1[8],ss1[10],ss1[2])
   else
    
  otg=ss1[9].to_i
 
  nach=ss1[8].to_i
  ost1=nach-otg
  bonus1.ost+=ost1
  ost2=bonus1.ost
  bonus1.save
   Mailer.deliver_bonus(ss1[6],ss1[4],ss1[5],ss1[8],ost2,ss1[2])
 end
     end
   end
   File.delete('public/data/'+file)

     redirect_to :controller=>'bonus1'
   end

 end


 #===========================
def zal_bonus11
    ll=0
   lll=0
   colline=0
   file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
     if colline==1

     else
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   cat=Bonus2.find(:first,:conditions=>["k1c=?",ss1[0]])
   if cat==nil
     cat1=Bonus2.new
   else
     cat1=cat
   end

    cat1.k1c=ss1[0]
    cat1.kbk=ss1[1]
    cat1.name=ss1[2]
    cat1.op=ss1[3]
    cat1.pic1=ss1[4]
    cat1.bonus_price=ss1[5]


    cat1.save
     end
   end
   redirect_to :controller=>'kt1'
 end

def zal_bonus12
    ll=0
   lll=0
   colline=0
   file=params[:file]
   IO.foreach('public/data/'+ file) do |line|
     colline+=1
     if colline==1

     else
    converter=Iconv.new('UTF-8','Windows-1251')
   ss=converter.iconv(line)
   ss1=ss.split(";")
   
   cat1=TovSpec.find(:first,:conditions=>["k1c=? and legal_id=?",ss1[0],ss1[2]])
   if cat1
    
   @tov=Cat1.find(:first,:conditions=>["k1c=?",ss1[0]])
  @tg2=Tov3.find(@tov.tov3_id)
  @tg1=Tov2.find(@tg2.tov2_id)
  @kod_f1=First1.find(@tg1.first1_id)
   cat1.k1c=ss1[0]
   cat1.price_spec=ss1[1]
   cat1.legal_id=ss1[2]
   cat1.brend=@tov.brend
   cat1.tg1=@tg1.first1_id
   cat1.tg2=@tg2.tov2_id
   cat1.tg3=@tov.tov3_id
   cat1.kod_f1=@kod_f1.kod
   cat1.save
   else
   cat1=TovSpec.new
  @tov=Cat1.find(:first,:conditions=>["k1c=?",ss1[0]])
  @tg2=Tov3.find(@tov.tov3_id)
  @tg1=Tov2.find(@tg2.tov2_id)
  @kod_f1=First1.find(@tg1.first1_id)
   cat1.k1c=ss1[0]
   cat1.price_spec=ss1[1]
   cat1.legal_id=ss1[2]
   cat1.brend=@tov.brend
   cat1.tg1=@tg1.first1_id
   cat1.tg2=@tg2.id
   cat1.tg3=@tov.tov3_id
   cat1.kod_f1=@kod_f1.kod
   cat1.save
   end
 
     end
   end
   File.delete('public/data/'+file)
   redirect_to :controller=>'kt1'
 end









#==========================
end
