class Cat1imgsController < ApplicationController
  # GET /cat1imgs
  # GET /cat1imgs.xml

  before_filter 'redaktor'

 
  def new
    t1=params[:cat1img][:pic].insert(0, '/big/')
    params[:cat1img][:pic]=t1
    @cat1img = Cat1img.new(params[:cat1img])
    @cat1img.save
    @cat1=Cat1.find(@cat1img.cat1_id)
    render :update do |page|
    page.replace_html( 'edit_tov', :partial=>'/part/edit_tov_pics',:object=>@cat1 )
  end
  end


  def update
    @cat1img = Cat1img.find(params[:id])
    t1=params[:cat1img][:pic].insert(0, '/big/')
    params[:cat1img][:pic]=t1
    @cat1img.update_attributes(params[:cat1img])
    @cat1=Cat1.find(@cat1img.cat1_id)
    render :update do |page|
    page.replace_html( 'edit_tov', :partial=>'/part/edit_tov_pics',:object=>@cat1 )
    end
   
  end


  def destroy
    @cat1img = Cat1img.find(params[:id])
    @cat1img.destroy
   @cat1=Cat1.find(params[:cat1_id])
    render :update do |page|
    page.replace_html( 'edit_tov', :partial=>'/part/edit_tov_pics',:object=>@cat1 )
  end

  end
end
