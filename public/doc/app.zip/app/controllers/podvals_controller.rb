class PodvalsController < ApplicationController
  # GET /podvals
  # GET /podvals.xml
  def index
    @podvals = Podval.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @podvals }
    end
  end

  # GET /podvals/1
  # GET /podvals/1.xml
  def show
    @podval = Podval.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @podval }
    end
  end

  # GET /podvals/new
  # GET /podvals/new.xml
  def new
    @podval = Podval.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @podval }
    end
  end

  # GET /podvals/1/edit
  def edit
    @podval = Podval.find(params[:id])
  end

  # POST /podvals
  # POST /podvals.xml
  def create
    @podval = Podval.new(params[:podval])

    respond_to do |format|
      if @podval.save
        flash[:notice] = 'Podval was successfully created.'
        format.html { redirect_to(@podval) }
        format.xml  { render :xml => @podval, :status => :created, :location => @podval }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @podval.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /podvals/1
  # PUT /podvals/1.xml
  def update
    @podval = Podval.find(params[:id])

    respond_to do |format|
      if @podval.update_attributes(params[:podval])
        flash[:notice] = 'Podval was successfully updated.'
        format.html { redirect_to(@podval) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @podval.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /podvals/1
  # DELETE /podvals/1.xml
  def destroy
    @podval = Podval.find(params[:id])
    @podval.destroy

    respond_to do |format|
      format.html { redirect_to(podvals_url) }
      format.xml  { head :ok }
    end
  end
end
