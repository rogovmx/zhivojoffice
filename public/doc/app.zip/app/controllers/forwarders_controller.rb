class ForwardersController < ApplicationController
  # GET /forwarders
  # GET /forwarders.xml
  layout 'vvk_fw'
  def index
    @forwarders = Forwarder.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @forwarders }
    end
  end

  # GET /forwarders/1
  # GET /forwarders/1.xml
  def show
    @forwarder = Forwarder.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @forwarder }
    end
  end

  # GET /forwarders/new
  # GET /forwarders/new.xml
  def new
    @forwarder = Forwarder.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @forwarder }
    end
  end

  # GET /forwarders/1/edit
  def edit
    @forwarder = Forwarder.find(params[:id])
  end

  # POST /forwarders
  # POST /forwarders.xml
  def create
    @forwarder = Forwarder.new(params[:forwarder])

    respond_to do |format|
      if @forwarder.save
        flash[:notice] = 'Forwarder was successfully created.'
        format.html { redirect_to(@forwarder) }
        format.xml  { render :xml => @forwarder, :status => :created, :location => @forwarder }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @forwarder.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /forwarders/1
  # PUT /forwarders/1.xml
  def update
    @forwarder = Forwarder.find(params[:id])

    respond_to do |format|
      if @forwarder.update_attributes(params[:forwarder])
        flash[:notice] = 'Forwarder was successfully updated.'
        format.html { redirect_to(@forwarder) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @forwarder.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /forwarders/1
  # DELETE /forwarders/1.xml
  def destroy
    @forwarder = Forwarder.find(params[:id])
    @forwarder.destroy

    respond_to do |format|
      format.html { redirect_to(forwarders_url) }
      format.xml  { head :ok }
    end
  end
end
