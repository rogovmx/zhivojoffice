class Cat1sController < ApplicationController
  # GET /cat1s
  # GET /cat1s.xml
  before_filter :authorize
   before_filter :redaktor

  def index
    @cat1s = Cat1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @cat1s }
    end
  end

  # GET /cat1s/1
  # GET /cat1s/1.xml
  def show
    #@cat1 = Cat1.find(params[:id])

    respond_to do |format|
      #format.html # show.html.erb
      format.html { redirect_to(:back) }
    end
  end

  # GET /cat1s/new
  # GET /cat1s/new.xml
  def new
    @cat1 = Cat1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @cat1 }
    end
  end

  # GET /cat1s/1/edit
  def edit
    @cat1 = Cat1.find(params[:id])
  end

  # POST /cat1s
  # POST /cat1s.xml
  def create
    @cat1 = Cat1.new(params[:cat1])

    respond_to do |format|
      if @cat1.save
        flash[:notice] = 'Cat1 was successfully created.'
       format.html { redirect_to(:back) }
       # format.xml  { render :xml => @cat1, :status => :created, :location => @cat1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @cat1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /cat1s/1
  # PUT /cat1s/1.xml
  def update
    @cat1 = Cat1.find(params[:id])

    respond_to do |format|
      if @cat1.update_attributes(params[:cat1])
        flash[:notice] = 'Cat1 was successfully updated.'
        #format.html { redirect_to(@cat1) }
        format.html { redirect_to(:back) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @cat1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /cat1s/1
  # DELETE /cat1s/1.xml
  def destroy
    @cat1 = Cat1.find(params[:id])
    @cat1.destroy

    respond_to do |format|
      format.html { redirect_to(cat1s_url) }
      format.xml  { head :ok }
    end
  end
end
