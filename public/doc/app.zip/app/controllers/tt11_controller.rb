class Tt11Controller < ApplicationController
 require 'fileutils'
 require 'parseexcel'
  
  
  def index
    musor
    nemusor
   # bonus
   # price


    Mailer.deliver_ep()
  end

  def musor
   #  file=params[:file]
  begin
    exel=Spreadsheet::ParseExcel.parse('public/data/musor.xls')
  rescue
    Mailer.deliver_netf('musor')
    return
  end
    #exel=Spreadsheet::ParseExcel.parse('public/ex1/opis22.xls')
    worksheet = exel.worksheet(0,0)

    worksheet.each { |row|
      i=0
      row.each { |cell|
     #i+=1

     if i==0
       cat_del=cell.to_s('UTF-8')
       cat=Cat1.find(:first,:select=>"k1c,vis",:conditions=>["k1c=?",cat_del])
       if cat
         if cat.vis==0
         else
          cat.vis=0
          cat.save!
         end
       end
     else
       return
     end
  }

}
 File.delete('public/data/musor.xls')
  end

  def nemusor
    begin
    exel=Spreadsheet::ParseExcel.parse('public/data/nemusor.xls')
  rescue
    Mailer.deliver_netf('nemusor')
    return
  end

     worksheet = exel.worksheet(0,0)

    worksheet.each { |row|
      i=0
      row.each { |cell|
     #i+=1

     if i==0
       cat_del=cell.to_s('UTF-8')
       cat=Cat1.find(:first,:select=>"k1c,vis",:conditions=>["k1c=?",cat_del])
       if cat
         if cat.vis==1
         else
           cat.vis=1
           cat.save!
         end
       end
     else
       return
     end
  }

}


 File.delete('public/data/nemusor.xls')
  end

  def bonus
    begin
    exel=Spreadsheet::ParseExcel.parse('public/data/bonus.xls')
  rescue
    Mailer.deliver_netf('bonus')
    return
  end
   worksheet = exel.worksheet(0,0)

    worksheet.each { |row|
      i=0
      row.each { |cell|
     #i+=1

     if i==0
       cat_del=cell.to_s('UTF-8')
       cat=Bonus1.find(:first,:select=>"k1c,ost",:conditions=>["k1c=?",cat_del])
       if cat
       else
         break
       end
     else
       return
     end
  }

}


     File.delete('public/data/bonus.xls')
  end

  def price
    begin
    exel=Spreadsheet::ParseExcel.parse('public/data/price.xls')
  rescue
    Mailer.deliver_netf('price')
    return
  end
    File.delete('public/data/price.xls')
  end

end
