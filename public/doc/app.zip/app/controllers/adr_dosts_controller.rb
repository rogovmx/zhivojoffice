class AdrDostsController < ApplicationController
  # GET /adr_dosts
  # GET /adr_dosts.xml
  #layout 'spens1'
 # layout 'kanct_admin'
  layout 'l_o1'
   before_filter :authorize

  def index
    @adr_dosts = AdrDost.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @adr_dosts }
    end
  end

  # GET /adr_dosts/1
  # GET /adr_dosts/1.xml
  def show
    @adr_dost = AdrDost.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @adr_dost }
    end
  end

  # GET /adr_dosts/new
  # GET /adr_dosts/new.xml
  def new
    @adr_dost = AdrDost.new
    @client=params[:client]
    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @adr_dost }
    end
  end

  # GET /adr_dosts/1/edit
  def edit
    @adr_dost = AdrDost.find(params[:id])
  end

  # POST /adr_dosts
  # POST /adr_dosts.xml
  def create
    @adr_dost = AdrDost.new(params[:adr_dost])

    respond_to do |format|
      if @adr_dost.save
        flash[:notice] = 'AdrDost was successfully created.'
       
        format.html { redirect_to :controller=>'cabinet',:action=>'first4' }
        #format.html { redirect_to(@adr_dost) }
        format.xml  { render :xml => @adr_dost, :status => :created, :location => @adr_dost }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @adr_dost.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /adr_dosts/1
  # PUT /adr_dosts/1.xml
  def update
    @adr_dost = AdrDost.find(params[:id])

    respond_to do |format|
      if @adr_dost.update_attributes(params[:adr_dost])
        flash[:notice] = 'AdrDost was successfully updated.'
        adr_doc_crm(@adr_dost.id)
        #format.html { redirect_to(@adr_dost) }
         format.html { redirect_to :controller=>'cabinet',:action=>'first4' }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @adr_dost.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /adr_dosts/1
  # DELETE /adr_dosts/1.xml
  def destroy
    @adr_dost = AdrDost.find(params[:id])
    @adr_dost.destroy

    respond_to do |format|
      format.html { redirect_to(adr_dosts_url) }
      format.xml  { head :ok }
    end
  end

  def adr_doc_crm(id)
     @adr_dost=AdrDost.find(params[:id])
     @adr_dost_crm=AdrDostCtm.new
     @adr_dost_crm.adr_dost_id=@adr_dost.id
     @adr_dost_crm.street_id=@adr_dost.street_id
     @adr_dost_crm.dom=@adr_dost.dom
     @adr_dost_crm.litera=@adr_dost.litera
     @adr_dost_crm.gjv=@adr_dost.gjv
     @adr_dost_crm.korpus=@adr_dost.korpus
     @adr_dost_crm.ofis=@adr_dost.ofis
     @adr_dost_crm.kv=@adr_dost.kv
     @adr_dost_crm.prim=@adr_dost.prim
     @adr_dost_crm.client_id=@adr_dost.client_id
     @adr_dost_crm.save
  end

end
