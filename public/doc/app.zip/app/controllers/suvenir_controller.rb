class SuvenirController < ApplicationController
   layout 'l_o1'
  def index
  end

end
