class IstsController < ApplicationController
  # GET /ists
  # GET /ists.xml

  layout 'l_o1'
   before_filter :authorize
   before_filter :admin_s
  def index
    @ists = Ist.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @ists }
    end
  end

  # GET /ists/1
  # GET /ists/1.xml
  def show
    @ist = Ist.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @ist }
    end
  end

  # GET /ists/new
  # GET /ists/new.xml
  def new
    @ist = Ist.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @ist }
    end
  end

  # GET /ists/1/edit
  def edit
    @ist = Ist.find(params[:id])
  end

  # POST /ists
  # POST /ists.xml
  def create
    @ist = Ist.new(params[:ist])

    respond_to do |format|
      if @ist.save
        flash[:notice] = 'Ist was successfully created.'
        format.html { redirect_to(@ist) }
        format.xml  { render :xml => @ist, :status => :created, :location => @ist }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @ist.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /ists/1
  # PUT /ists/1.xml
  def update
    @ist = Ist.find(params[:id])

    respond_to do |format|
      if @ist.update_attributes(params[:ist])
        flash[:notice] = 'Ist was successfully updated.'
        format.html { redirect_to(@ist) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @ist.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /ists/1
  # DELETE /ists/1.xml
  def destroy
    @ist = Ist.find(params[:id])
    @ist.destroy

    respond_to do |format|
      format.html { redirect_to(ists_url) }
      format.xml  { head :ok }
    end
  end
end
