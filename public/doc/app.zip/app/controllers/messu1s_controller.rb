class Messu1sController < ApplicationController
  # GET /messu1s
  # GET /messu1s.xml
  def index
    @messu1s = Messu1.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @messu1s }
    end
  end

  # GET /messu1s/1
  # GET /messu1s/1.xml
  def show
    @messu1 = Messu1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @messu1 }
    end
  end

  # GET /messu1s/new
  # GET /messu1s/new.xml
  def new
    @messu1 = Messu1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @messu1 }
    end
  end

  # GET /messu1s/1/edit
  def edit
    @messu1 = Messu1.find(params[:id])
  end

  # POST /messu1s
  # POST /messu1s.xml
  def create
    @messu1 = Messu1.new(params[:messu1])

    respond_to do |format|
      if @messu1.save
        flash[:notice] = 'Messu1 was successfully created.'
        format.html { redirect_to(@messu1) }
        format.xml  { render :xml => @messu1, :status => :created, :location => @messu1 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @messu1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /messu1s/1
  # PUT /messu1s/1.xml
  def update
    @messu1 = Messu1.find(params[:id])

    respond_to do |format|
      if @messu1.update_attributes(params[:messu1])
        flash[:notice] = 'Messu1 was successfully updated.'
        format.html { redirect_to(@messu1) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @messu1.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /messu1s/1
  # DELETE /messu1s/1.xml
  def destroy
    @messu1 = Messu1.find(params[:id])
    @messu1.destroy

    respond_to do |format|
      format.html { redirect_to(messu1s_url) }
      format.xml  { head :ok }
    end
  end
end
