class MainController < ApplicationController
  layout 'index'

 require 'iconv'

  def index
    @menu=1


  end

  def about
  @menu=2
  @path='о компании / '
  @path += ' о проекте' if params[:smenu] == '1'
  @path += ' миссия' if params[:smenu] == '11'
  @path += ' история' if params[:smenu] == '2'
  @path += ' наши ценности' if params[:smenu] == '3'
  @path += ' статьи о живом офисе' if params[:smenu] == '4'
  @path += ' наши достижения' if params[:smenu] == '5'
  end

  def letter
   @menu=2
   @path='о компании / '
   @path += ' наши достижения'
  end

  def sotrud
    @menu=4
  @path='сотрудники / '
  @path += ' алфавитный указатель' if params[:smenu] == '1'
  @path += ' структура' if params[:smenu] == '2'
     @stuff=Office1.find_by_sql(["select distinct * from office1s order by last_name asc"])
       @stuff2=Office1.find_by_sql(["select distinct last_name from office1s order by last_name asc"])
       @alf=[]
      @stuff2.each do |st|
    #    converter=Iconv.new('Windows-1251','UTF-8')
   # bb2=converter.iconv(bb.reserv)
      @alf << st.last_name[0,2]
      end
      @alfa=@alf.uniq
@quant = @alf.size
@col = (@quant/3) + 3
  end





    def redir1
    redirect_to("http://www.segment.ru/rearticles/show/3960/101/501/")
  end
   def redir2
    redirect_to("http://www.segment.ru/rearticles/show/3995/")
  end
   def redir3
    redirect_to("http://www.segment.ru/news/show/24750/")
  end
   def redir4
    redirect_to("http://www.segment.ru/news/show/24675/")
  end
   def redir5
    redirect_to("http://www.segment.ru/news/show/24641/")
  end
 def redir6
    redirect_to("http://content.yudu.com/Library/A1q7z2/OfficeFileMagazineRu/resources/index.htm?referrerUrl")
  end


end
