class ComentsController < ApplicationController
  # GET /coments
  # GET /coments.xml
  layout 'kanct'
  def index

    @coment_name =Coment.find(:first ,:conditions=>['k1c=?',params[:k1c]])
    if @coment_name

    @coments = Coment.find(:all ,:conditions=>['k1c=?',params[:k1c]])

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @coments }
    end
    else
      redirect_to :back
    end

  end

  # GET /coments/1
  # GET /coments/1.xml
  def show
    @coment = Coment.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @coment }
    end
  end

  # GET /coments/new
  # GET /coments/new.xml
  def new
    @coment = Coment.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @coment }
    end
  end

  # GET /coments/1/edit
  def edit
    @coment = Coment.find(params[:id])
  end

  # POST /coments
  # POST /coments.xml
  def create
    @coment = Coment.new(params[:coment])

    respond_to do |format|
      if @coment.save
        flash[:notice] = 'Coment was successfully created.'
       # format.html { redirect_to(@coment) }
       format.html { redirect_to :controller=>'kt1'}
        format.xml  { render :xml => @coment, :status => :created, :location => @coment }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @coment.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /coments/1
  # PUT /coments/1.xml
  def update
    @coment = Coment.find(params[:id])

    respond_to do |format|
      if @coment.update_attributes(params[:coment])
        flash[:notice] = 'Coment was successfully updated.'
        format.html { redirect_to(@coment) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @coment.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /coments/1
  # DELETE /coments/1.xml
  def destroy
    @coment = Coment.find(params[:id])
    @coment.destroy

    respond_to do |format|
      format.html { redirect_to(coments_url) }
      format.xml  { head :ok }
    end
  end
end
