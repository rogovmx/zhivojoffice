class SAdminController < ApplicationController

  
  def index
   user
  


  
  end

  private

  def user
    @user=User.find_by_id(session[:user_id])

 
     unless @user==nil
       if @user.role != 'admin_s'
       redirect_to :controller=>'kt1'
       end
     else
       redirect_to :controller=>'login',:action=>'login'
     end 
       
     

  end


end
