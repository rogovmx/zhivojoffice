class Office1sController < ApplicationController
  # GET /Office1s
  # GET /Office1s.xml
  def index
    @office11s = Office1.all  :order=>'last_name'

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @office11s }
    end
  end

  # GET /Office1s/1
  # GET /Office1s/1.xml
  def show
    @office11 = Office1.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @office11 }
    end
  end

  # GET /Office1s/new
  # GET /Office1s/new.xml
  def new
    @office11 = Office1.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @office11 }
    end
  end

  # GET /Office1s/1/edit
  def edit
    @office11 = Office1.find(params[:id])
  end

  # POST /Office1s
  # POST /Office1s.xml
  def create
    @office11 = Office1.new(params[:Office1])

    respond_to do |format|
      if @office11.save
        format.html { redirect_to(@office11, :notice => 'Office1 was successfully created.') }
        format.xml  { render :xml => @office11, :status => :created, :location => @office11 }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @office11.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /Office1s/1
  # PUT /Office1s/1.xml
  def update
    @office11 = Office1.find(params[:id])

    respond_to do |format|
      if @office11.update_attributes(params[:Office1])
        format.html { redirect_to(@office11, :notice => 'Office1 was successfully updated.') }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @office11.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /Office1s/1
  # DELETE /Office1s/1.xml
  def destroy
    @OfficOe1 = Office1.find(params[:id])
    @office11.destroy

    respond_to do |format|
      format.html { redirect_to(Office1s_url) }
      format.xml  { head :ok }
    end
  end
end
