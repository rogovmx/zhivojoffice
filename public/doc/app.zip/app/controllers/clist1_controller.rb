class Clist1Controller < ApplicationController

   layout 'l_o1'
   before_filter :authorize
   before_filter :admin_s
  def index
    @client=Client.find :all

  end

end
