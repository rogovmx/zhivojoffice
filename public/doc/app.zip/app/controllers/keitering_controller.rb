class KeiteringController < ApplicationController

  def user
    @user=User.find_by_id(session[:user_id])
  end

     def cart
     user
     if @user
     @cart=KeitCart.find :all,:conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     @cart_count=KeitCart.count :conditions=>['user_id=? or session_id=?',@user.id,session.session_id]
     else
        @cart=KeitCart.find :all,:conditions=>[' session_id=?',session.session_id]
        @cart_count=KeitCart.count :conditions=>['session_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
      @cart_sum += cart.price*cart.quantity 
       end

     end


   def edit_cart
    user
    cart

  if params[:order]
   order=Korder.new(params[:order])

   flag=0
     for cart in @cart do
       flag+= cart.quantity if cart.quantity
       order.likeit << Likeit.new(:keitering_id =>cart.keitering_id  , :price=>cart.price ,:quantity =>cart.quantity )
    end
    if flag >0
     if order.save

       Mailer.deliver_keit1(order)
      KeitCart.delete_all(['user_id=?',@user.id]) if @user
      KeitCart.delete_all(['session_id=?',session.session_id])
        flash.now[:notice] = "Заказ отправлен"
        redirect_to :back
     else
       flash.now[:notice] = "Обязательно заполните поля: Имя и Телефон"

     end
    else
      redirect_to :action=>'no_ver'
    end
else
   if @cart_count == 0
     redirect_to :action=>'no_ver'
    end
end


  end

 def no_ver

 end 

    def tov
    user
    cart

    @s=Keitering.find(params[:id])


  end


   def create_cart
     user

    @cart = KeitCart.new(params[:keit_cart])
    @cart.save
    #render :text=>'заказано'
    #redirect_to :action=>'edit_cart'
  end




     def del_cart
     user
     if @user
       KeitCart.delete_all(['user_id=?',@user.id])
       KeitCart.delete_all(['session_id=?',session.session_id])
     else
        KeitCart.delete_all(['session_id=?',session.session_id])
     end
    redirect_to :action=>'edit_cart'
  end

     
   def del_cart_item

    cart_item=KeitCart.find :first,:conditions=>['id=?',params[:id]]
    cart_item.destroy

    redirect_to :back
  end


  def index
  user
  @set=Keitering.find :all , :conditions=>['sets=?',1]
  @assorty=Keitering.find :all, :conditions=>['sets=?',0]
  end

  def about

  end

  
end
