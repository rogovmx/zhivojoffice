class BestsellersController < ApplicationController
  # GET /bestsellers
  # GET /bestsellers.xml
   layout 'l_o1'
   before_filter :authorize
   before_filter :admin_s
  def index
    @bestsellers = Bestseller.find(:all)

    respond_to do |format|
      format.html # index.html.erb
      format.xml  { render :xml => @bestsellers }
    end
  end

  # GET /bestsellers/1
  # GET /bestsellers/1.xml
  def show
    @bestseller = Bestseller.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.xml  { render :xml => @bestseller }
    end
  end

  # GET /bestsellers/new
  # GET /bestsellers/new.xml
  def new
    @bestseller = Bestseller.new

    respond_to do |format|
      format.html # new.html.erb
      format.xml  { render :xml => @bestseller }
    end
  end

  # GET /bestsellers/1/edit
  def edit
    @bestseller = Bestseller.find(params[:id])
  end

  # POST /bestsellers
  # POST /bestsellers.xml
  def create
    @bestseller = Bestseller.new(params[:bestseller])

    respond_to do |format|
      if @bestseller.save
        flash[:notice] = 'Успешно добавлен.'
        format.html { redirect_to(@bestseller) }
        format.xml  { render :xml => @bestseller, :status => :created, :location => @bestseller }
      else
        format.html { render :action => "new" }
        format.xml  { render :xml => @bestseller.errors, :status => :unprocessable_entity }
      end
    end
  end

  # PUT /bestsellers/1
  # PUT /bestsellers/1.xml
  def update
    @bestseller = Bestseller.find(params[:id])

    respond_to do |format|
      if @bestseller.update_attributes(params[:bestseller])
        flash[:notice] = 'Успешно обновлен.'
        format.html { redirect_to(@bestseller) }
        format.xml  { head :ok }
      else
        format.html { render :action => "edit" }
        format.xml  { render :xml => @bestseller.errors, :status => :unprocessable_entity }
      end
    end
  end

  # DELETE /bestsellers/1
  # DELETE /bestsellers/1.xml
  def destroy
    @bestseller = Bestseller.find(params[:id])
    @bestseller.destroy

    respond_to do |format|
      format.html { redirect_to(bestsellers_url) }
      format.xml  { head :ok }
    end
  end
end
