class Raspr2Controller < ApplicationController
layout 'vvk'
   require "will_paginate"

   def user
    @user=User.find_by_id(session[:user_id])
  end

 def cart
     user
     if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
        @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum= 0

     @cart.each do |cart|
       @cart_sum += cart.price*cart.quantity if cart.price
     end

     end


  def  per_page

    @per_page=session[:per_page]
    if @per_page==nil
      @per_page=5
    end
    return @per_page
  end


  def index
     session[:original_uri]=request.request_uri
     user
     cart
     @per_page=30
   
   
    @raspr1s=Raspr1.paginate_by_sql(["select distinct * from raspr1s where quantity >0 and k1c in (select k1c from cat1s)"] , :page => params[:page], :per_page =>@per_page,:order=> 'id')





  end


  def create_cart

  
  @cart = Cart.new(params[:cart])
  @m_quan=params[:m_quan].to_i
  @cart.quantity=@m_quan if @cart.quantity >= @m_quan
  @cart.save
  @raspr2=Raspr1.find(params[:id])
  @raspr2.quantity-=@cart.quantity
  @raspr2.save
     end

def z_q
  @raspr2=Raspr1.find(params[:id])
  qq=@raspr2.quantity.to_s
  render :text=>qq
  #render :text=>'77'
  
end

end
