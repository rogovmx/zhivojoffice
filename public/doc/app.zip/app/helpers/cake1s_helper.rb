module Cake1sHelper

    def oc_cake

      @user=User.find_by_id(session[:user_id])
       if @user
     @cart=Cakecart.find :all,:conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     @cart_count=Cakecart.count :conditions=>['User_id=? or session_id=?',@user.id,session.session_id]
     else
       @cart=Cakecart.find :all,:conditions=>[' session_id=?',session.session_id]
        @cart_count=Cakecart.count :conditions=>['session_id=?',session.session_id]
     end

     @cart_sum=0
     @cart.each do |cart|
       @cart_sum+=cart.price*cart.quantity  if cart.price
     end


      render :partial=>'/cake1s/oc',:cart=>@cart

   end

end
