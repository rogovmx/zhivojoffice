
module ApplicationHelper
  
  def user_id
     @user=User.find_by_id(session[:user_id])
     if @user
       return @user.id
     else
       return 0
     end
  end
  
  def user_name
    @user=User.find_by_id(session[:user_id])
    return @user.scr_name
  end

  def login?
    if User.find_by_id(session[:user_id])
      return true
    else
      return false
    end

  end


  def tov3all(id)
    @tov3=Tov3.find(id)
    @tov3all = Tov3.find :all , :conditions=>['tov2_id=?',@tov3.tov2_id]
    render :partial=>'/part2/tov3all', :tov3all=>@tov3all , :tov3=>@tov3
  end


  def hk(id)
    @tov3=Tov3.find(id)
    @tov2=Tov2.find(@tov3.tov2_id)
    @first=First1.find(@tov2.first1_id)
   @tgn=0
      render :partial=>'/part2/hk',:tov3=>@tov3,:tov2=>@tov2, :tgn=>@tgn
  end


  def hk_tgn(id)
    @tov3=Tov3.find(id)
    @tov2=Tov2.find(@tov3.tov2_id)
    @first=First1.find(@tov2.first1_id)
     @tgn=1
      render :partial=>'/part2/hk',:tov3=>@tov3,:tov2=>@tov2, :tgn=>@tgn
  end


  def hk2(id)
    @tov2=Tov2.find(id)
    @gr=@tov2.name
    @first=First1.find(@tov2.first1_id)
    render :partial=>'/part2/hk2',:gr=>@gr,:tov2=>@tov2
  end


  def hk_tov(id)
    @tov_hk=Cat1.find(id)
    @tov3_hk=Tov3.find(@tov_hk.tov3_id)
    @tov2_hk=Tov2.find(@tov3_hk.tov2_id)
     @first=First1.find(@tov2_hk.first1_id)
    render :partial=>'/part2/hk_tov',:tov3_hk=>@tov3_hk,:tov2_hk=>@tov2_hk,:htov_hk=>@tov_hk
  end

  def tov_h(id ,order,brend)
    
   #@tg=Cat1.find_by_sql(['select distinct tg from cat1s where tov3_id =?',id])
    #@tg=Cat1.find :all, :conditions=>['tov3_id =? and tg1=?',params[:id],1]
    if brend==nil and order==nil
       @tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=?',id,1], :page => params[:page], :per_page =>  5,:order=> 'price'
    elsif brend==nil and order!=nil
       @tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=?',id,1], :page => params[:page], :per_page =>  5,:order=> order
    elsif  brend!=nil and order==nil
       @tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=? and brend=?',id,1,brend], :page => params[:page], :per_page =>  5,:order=> 'portg'
    else
       @tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=? and brend=?',id,1,brend], :page => params[:page], :per_page =>  5,:order=> order
    end
    #if order==nil
    #@tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=?',id,1], :page => params[:page], :per_page =>  10,:order=> 'portg'
    #else
    #@tg=Cat1.paginate :conditions=>['tov3_id =? and tg1=?',id,1], :page => params[:page], :per_page =>  10,:order=> order
    #end
    
      render :partial=>'/part/tov_h',:tg=>@tg
  end

  def bs

    render :partial=>'/part/ban'
   # order='por'
    # @bestseller=Bestseller.find :all,:order=>order
     #render :partial=>'/part/bs_h',:bestseller=>@bestseller
  end
    def sp
        order='por'
     @sp=Ist.find :all,:order=>order
     render :partial=>'/part/sp_h',:bestseller=>@bestseller
  end
   def tagcloud
     order='por'
     @tagc = TagCloud.find :all,:order =>order
     render :partial=>'/part/tagcloud',:tagc=>@tagc
   end
   def messager_m
     @user=User.find_by_id(session[:user_id])
     
   end

   def oc(id)
     if id==0
     @st=0
     else
       
      @cat1=Cat1.find(id)
      @st=Cat1.find :first , :conditions=>['id=?',@cat1.st]
      #@st=@cat1.st
     end
      @user=User.find_by_id(session[:user_id])
       if @user
     @cart=Cart.find :all,:conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     @cart_count=Cart.count :conditions=>['User_id=? or sesion_id=?',@user.id,session.session_id]
     else
       @cart=Cart.find :all,:conditions=>[' sesion_id=?',session.session_id]
        @cart_count=Cart.count :conditions=>['sesion_id=?',session.session_id]
     end
     @cart_sum_bonus=0
     @cart_bonus=Cart.find :all,:conditions=>[' sesion_id=? and otdel != ?',session.session_id,'raspr']

     @cart_bonus.each do |cart1|
       @cart_sum_bonus+=cart1.price*cart1.quantity if cart1.price
     end
     @cart_sum=0
     @cart.each do |cart|
       @cart_sum+=cart.price*cart.quantity  if cart.price
     end


      render :partial=>'/part2/oc',:cart=>@cart

   end

    def btg1har?(id,par_s,edit)
    #@btg1har=Btg1har.find :all , :conditions=>['btg1_id=? and s=?',id,s]
    
    @tmp=Bcat1.find :all , :conditions=>['btg1_id=?',id]
    @btg1har=@tmp.map{|b| [b.send('s'+par_s),b.send('s'+par_s)]}.compact
    
     @btg1har.unshift(['no', 'no'])  if edit=='no'
      
    if @btg1har.size != 0
         return true
    else
        return false
    end
  end

    def cat1har?(id,par_s)
    #@btg1har=Btg1har.find :all , :conditions=>['btg1_id=? and s=?',id,s]

    @tmp=Bcat1.find :all , :conditions=>['btg1_id=?',id]
    @btg1har=@tmp.map{|b| b.send('s'+par_s) if b.send('s'+par_s) != 'no'}.compact.uniq.sort
    
    if @btg1har.uniq.size > 1
         return true
    else
        return false
    end
  end

    
 
    
    
   
   def foo1

  
#    show=rand(3)+1
#
#    if show == 1
#       render :partial=>'/part/podval1'
#
#    elsif show == 2
#        render :partial=>'/part/podval2'
#     elsif show == 3
#         render :partial=>'/part/podval3'
#    elsif show == 4
         render :partial=>'/part/podval6'
#    end

   end

   def comics
     #show=rand(2)+1
     
     #if show == 1
      render :partial=>'/part/comics1'
         #elsif show == 2
     #  render :partial=>'/part/comics3'
     #elsif show == 3
       #render :partial=>'/part/comics2'
    # end
   end


   
end
